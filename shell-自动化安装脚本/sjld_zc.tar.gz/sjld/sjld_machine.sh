#!/bin/bash

#固定参数
mysql_host="127.0.0.1"
mysql_port="3306"
mysql_user="rhino"
mysql_passwd="rhino"
mysql_path="/home/rhino/mysql-5.6.25-linux-x86_64/bin/mysql"

pwd_path=$(cd `dirname $0`; pwd)
neo4j_path="/home/rhino/neo4j-community-3.4.7/bin"

#函数:错误执行脚本打印help帮助信息
help()
{
cat<<HELP
#-----------------------------------------------------------------------------------#
###使用说明###

./sjld_machine.sh -a id编码  -b e_id编码(200开头)   -c 类型（手机/手机卡/车辆） -d  imsi/imei/车牌号  -e 实名认证号  -f 手机号(只有类型为手机卡时填写)

样例:

手机卡     ./sjld_machine.sh -a 1001  -b 2001001  -c 手机卡 -d  466015061127087  -e 622722199909114966   -f  15061121111

手机       ./sjld_machine.sh -a 1002  -b 2001002  -c 手机   -d  466115061127088  -e 622722199909114966

车辆       ./sjld_machine.sh -a 1003  -b 2001003  -c 车辆   -d  苏A8Q888  -e 622722199909114966
#-----------------------------------------------------------------------------------#
HELP
}

#函数:判断上条命令是否执行成功
if_else()
{
    if [ $1 = 0 ];then
        echo "succeed"
    else
        echo "failed"
        exit 1
    fi
}

#函数:选择要插入的数据类型
shaixuan()
{
    if [ "$1" = "手机卡" ];then
        v=$2
    elif  [ "$1" = "手机" ];then
        v=$3
    else
        v=$4
    fi
    echo $v
    #return "$v"
}
#循环读取参数并赋值
while getopts ":a:b:c:d:e:f:" opt
do
    case $opt in
        a)
        id=$OPTARG
	echo "id:$OPTARG"
        ;;
        b)
        e_id=$OPTARG
        echo "e_id:$OPTARG"
        ;;
        c)
        e_type=$OPTARG
        echo "e_type:$OPTARG"
        ;;
        d)
        im=$OPTARG
        echo "im:$OPTARG"
        ;;
        e)
        smrzh=$OPTARG
        echo "smrzh:$OPTARG"
        ;;
        f)
        Tel=$OPTARG
        echo "Tel:$OPTARG"
        ;;
        ?)
        echo "input error"
        exit 1;;
    esac
done
#判断传参是否不为空
if [ "$e_type" = "手机卡" ];then
    if [ "$id" = "" ] || [ "$e_id" = "" ] || [ "$e_type" = "" ] || [ "$im" = "" ] || [ "$smrzh" = "" ] || [ "$Tel" = "" ];then
        help
        exit 1
    else
        echo "------------输入参数成功--------------"
    fi
elif [ "$e_type" = "车辆" ] || [ "$e_type" = "手机" ];then
    if [ "$id" = "" ] || [ "$e_id" = "" ] || [ "$e_type" = "" ] || [ "$im" = "" ] || [ "$smrzh" = "" ];then
        help
        exit 1
    else
        echo "------------输入参数成功--------------"
    fi
else
    echo "------------输入类型错误--------------"
    help
    exit 1
fi


#手机卡
values1="{\"id\":$id,\"e_id\":\"$e_id\",\"e_type\":\"基础标签\",\"label_value\":\"手机卡,江苏,$Tel,$im\",\"entity_desc\":\"{\\\"唯一标识码\\\":\\\"$im\\\",\\\"类型\\\":\\\"手机卡\\\",\\\"实名认证号\\\":\\\"$smrzh\\\",\\\"手机号\\\":\\\"$Tel\\\"}\"}"
#手机
values2="{\"id\":$id,\"e_id\":\"$e_id\",\"e_type\":\"基础标签\",\"label_value\":\"手机,华为,荣耀10,黑色,$im\",\"entity_desc\":\"{\\\"唯一标识码\\\":\\\"$im\\\",\\\"类型\\\":\\\"手机\\\",\\\"实名认证号\\\":\\\"$smrzh\\\"}\",\"app_name\":\"乐酷\"}"
#车辆
values3="{\"id\":$id,\"e_id\":\"$e_id\",\"e_type\":\"基础标签\",\"label_value\":\"车辆,宝马,$im,江苏,红色\",\"entity_desc\":\"{\\\"唯一标识码\\\":\\\"$im\\\",\\\"类型\\\":\\\"车辆\\\",\\\"实名认证号\\\":\\\"$smrzh\\\"}\"}"
#插数据模板
#curl -XPOST http://0.0.0.0:9200/entity_label1/entity_label1?pretty -H Content-Type:application/json -d {"id":79,"e_id":"1006677","e_type":"基础标签","label_value":"车辆,宝马,466015061127088,江苏,红色","entity_desc":"{\"唯一标识码\":\"466015061127088\",\"类型\":\"车辆\",\"实名认证号\":\"622700199909116666\"}"}
values=$(shaixuan $e_type $values1 $values2  $values3)
echo $values
echo "------------插入数据到es--------------"
echo  curl -XPOST "http://0.0.0.0:9200/entity_label1/entity_label1?pretty" -H "Content-Type:application/json" -d "$values"
echo "------------插入结果--------------"
curl -XPOST "http://0.0.0.0:9200/entity_label1/entity_label1?pretty" -H "Content-Type:application/json" -d "$values"
if_else $?


echo "------------造右侧浮窗的信息--------------"
#手机卡
insert1="INSERT INTO data_radar.basic_e_machine  VALUES ('$id','$e_id','$e_type', '$e_type', '移动', NULL,  '$im', '$Tel', NULL, NULL, '江苏', NULL,  '$smrzh', 'admin', 1585188000);"
#手机
insert2="INSERT INTO data_radar.basic_e_machine  VALUES ('$id', '$e_id','$e_type', '$e_type', '华为', '荣耀10', NULL, NULL, '$im', NULL, '江苏', '红色', '$smrzh', 'admin', 1585188000);"
#车辆
insert3="INSERT INTO data_radar.basic_e_machine  VALUES ('$id', '$e_id','$e_type', '$e_type', '宝马', 'Z5',  NULL, NULL,  NULL,'$im', '江苏',  '红色','$smrzh', 'admin', 1585188000);"
insert=$(shaixuan $e_type "$insert1" "$insert2" "$insert3")
echo $insert
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

echo "-----------手机卡的轨迹和活动范围-------------"
insert="INSERT INTO safe_sjld.trs_dpi  VALUES ( 20, 19, 30, 28,1584928800000, 1584929100000, 1584929100000, 15061127, 8080, 15062234, 9999, '$im', '$Tel', '466115061127087', 'zc', '460-00f-005e63e2', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.798172', '31.968729', '162.168.168.71', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200325',min=120)"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.trs_dpi VALUES ( 20, 19, 30, 28,1585015200000, 1585015500000, 1585015500000, 15061127, 8080, 15062234, 9999, '$im', '$Tel', '466115061127087', 'zc', '460-00f-001', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.973487', '32.127984', '162.168.168.74', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200324',min=120);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.trs_dpi  VALUES ( 20, 19, 30, 28,1585101600000, 1584928800000, 1584929100000, 15061127, 8080, 15062234, 9999, '$im', '$Tel', '466115061127087', 'zc', '460-00f-007', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.805969', '32.039888', '162.168.168.74', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200323',min=120);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.trs_dpi  VALUES ( 20, 19, 30, 28,1585188000000, 1585188300000, 1585188300000, 15061127, 8080, 15062234, 9999, '$im', '$Tel', '466115061127087', 'zc', '460-00f-032', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.8198899996', '31.9591667986', '162.168.168.74', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200326',min=120);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

echo "-----------手机详情-------------"
#手机详情-->机器档案
#5010137	5010137	LeKu	   乐酷	D0005	乐酷
#5020022	5020022	YingYongBao	应用宝	D0005	应用宝
#5050125	5050125	AiJiKe	爱极客	D0005	爱极客
insert="INSERT INTO safe_sjld.dp_app_count  VALUES ('$e_id', '$im', '', '', '$im',501, 5010137,26, 1584928800,1584929100);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.dp_app_count  VALUES ('$e_id', '$im', '', '', '$im',502, 5020022,11, 1584842400,1585015200);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.dp_app_count  VALUES ('$e_id', '$im','', '','$im',505, 5050125,26, 1584812400,1585015200);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#手机详情-->机器档案账号密码
insert="INSERT INTO safe_sjld.topic_acc_passwd  VALUES ('$e_id', '$im', '', '','$im', 501, 5010137, 'www.LeKu.com', '232123@qq.com', '123456', 12, 1584928800, 1584929100),('$e_id', '$Tel', '', '','$im', 527, 5270137, 'www.zhaopin.com', '232123@qq.com', '123456', 12, 1584812400,1585015200);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#手机详情-->基础信息
insert="INSERT INTO safe_sjld.device_profile  VALUES ('$e_id', '$im', '', '', '$im', 1584928800, 1584929100, 0, '1', 0, '460', 'admin', 1584928800);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#手机详情-->标签
insert="INSERT INTO safe_sjld.topic_overseas  VALUES ('$e_id','$im','','','$im','日本',22,1584928800,1584929100);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.topic_language  VALUES ('$e_id', '$im', '', '', '$im', 17,26,1584928800, 1584929100);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.topic_language  VALUES ('$e_id', '$im', '', '', '$im', 5010137,19,1584928800, 1584929100);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.topic_sensitive_area  VALUES ('$e_id', '$im', '', '', '$im', 1,19,1584928800, 1584929100);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#手机详情-->机器档案日历
insert="INSERT INTO safe_sjld.rili VALUES ('$e_id', '$im','','$im','', '2020-03-23');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

echo "-----------手机的轨迹和活动范围-------------"
insert="INSERT INTO safe_sjld.trs_dpi  VALUES ( 20, 19, 30, 28,1584928800000, 1584929100000, 1584929100000, 15061127, 8080, 15062234, 9999, '466115061127087','15061127087','$im', 'zc', '460-00f-005e63e2', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.798172', '31.968729', '162.168.168.71', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200325',min=120)"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.trs_dpi VALUES ( 20, 19, 30, 28,1585015200000, 1585015500000, 1585015500000, 15061127, 8080, 15062234, 9999, '466115061127087','15061127087','$im', 'zc', '460-00f-001', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.973487', '32.127984', '162.168.168.74', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200324',min=120);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.trs_dpi  VALUES ( 20, 19, 30, 28,1585101600000, 1584928800000, 1584929100000, 15061127, 8080, 15062234, 9999, '466115061127087','15061127087','$im', 'zc', '460-00f-007', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.805969', '32.039888', '162.168.168.74', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200323',min=120);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.trs_dpi  VALUES ( 20, 19, 30, 28,1585188000000, 1585188300000, 1585188300000, 15061127, 8080, 15062234, 9999, '466115061127087','15061127087','$im', 'zc', '460-00f-032', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.8198899996', '31.9591667986', '162.168.168.74', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200326',min=120);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#-----关系图-----
echo "------------关系图--------------"
node1="\"$e_id\",\"物品\",\"手机卡\",\"手机卡\",\"移动\",\"\",\"$im\",\"$Tel\",\"\",\"\",\"江苏\",\"\",\"$smrzh\",\"$e_id\""
node2="\"$e_id\",\"物品\",\"手机\",\"手机\",\"华为\",\"荣耀10\",\"\",\"\",\"$im\",\"\",\"\",\"黑色\",\"$smrzh\",\"$e_id\""
node3="\"$e_id\",\"物品\",\"车辆\",\"车辆\",\"宝马\",\"E34\",\"\",\"\",\"\",\"$im\",\"江苏\",\"红色\",\"$smrzh\",\"$e_id\""
node=$(shaixuan $e_type "$node1" "$node2" "$node3")
#停止neo4j
$neo4j_path/neo4j  stop
#备份库
rm -rf $pwd_path/graph_csv/graph.db.dump;$neo4j_path/neo4j-admin dump --database=graph.db --to=$pwd_path/graph_csv
#删除库
rm -rf $neo4j_path/../data/databases/graph.db
#修改csv数据
rm -rf $pwd_path/graph_csv/graph_new/basic_e_location.csv;cp $pwd_path/graph_csv/basic_e_location.csv  $pwd_path/graph_csv/graph_new/
if [ "$e_type" = "手机卡" ];then
    sed -i "/2002010/d"   $pwd_path/graph_csv/graph_new/basic_e_machine.csv
    sed -i "s/2002010/$e_id/g"  $pwd_path/graph_csv/graph_new/*.csv
elif  [ "$e_type" = "手机" ];then
    sed -i "/2000011/d"   $pwd_path/graph_csv/graph_new/basic_e_machine.csv
    sed -i "s/2000011/$e_id/g"  $pwd_path/graph_csv/graph_new/*.csv
else
    sed -i "/2000021/d"   $pwd_path/graph_csv/graph_new/basic_e_machine.csv
    sed -i "s/2000021/$e_id/g"  $pwd_path/graph_csv/graph_new/*.csv
fi
echo "$node"
echo "$node" >>  $pwd_path/graph_csv/graph_new/basic_e_machine.csv
#导入csv数据
$neo4j_path/neo4j-admin import --database=graph.db --mode=csv  --nodes "$pwd_path/graph_csv/graph_new/basic_e_location.csv" --nodes "$pwd_path/graph_csv/graph_new/basic_e_machine.csv" --nodes "$pwd_path/graph_csv/graph_new/basic_e_person.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_m_m_guishu.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_l_chuxian.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_m_guishu.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_qinshu.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tonglian.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongshi.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongxiang.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongxing.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongxue.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongzhu.csv" --delimiter=',' --ignore-duplicate-nodes=true --ignore-missing-nodes=true --ignore-extra-columns=true
#启动neo4j
$neo4j_path/neo4j  start
echo "------------end--------------"
