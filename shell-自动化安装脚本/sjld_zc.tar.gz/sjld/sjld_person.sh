#!/bin/bash

#固定参数
mysql_host="127.0.0.1"
mysql_port="3306"
mysql_user="rhino"
mysql_passwd="rhino"
mysql_path="/home/rhino/mysql-5.6.25-linux-x86_64/bin/mysql"

pwd_path=$(cd `dirname $0`; pwd)
neo4j_path="/home/rhino/neo4j-community-3.4.7/bin"

#函数:错误执行脚本打印help帮助信息
help()
{
cat<<HELP
#-----------------------------------------------------------------------------------#
###使用说明###

./sjld_person.sh -a id编码  -b e_id编码  -c 姓名 -d 性别  -e 证件号  -f 手机号

###人员信息除了传入的参数其他信息均固定###

'19960324', '汉族', '江苏省南京市', '中国', '江苏省', '南京市', '江宁区', '中新赛克', 

'B血', '普通话', '方脸', 185, 70.00, '工程师', '本科', '无党派', '未婚', '近视 短发'

###样例###

./sjld_person.sh -a 1001  -b 1001003  -c Tom -d 男  -e 622700199909116666  -f 15061121111
#-----------------------------------------------------------------------------------#
HELP
}

#函数:判断上条命令是否执行成功
if_else()
{
    if [ $1 = 0 ];then
        echo "succeed"
    else
        echo "failed"
        exit 1
    fi
}

#循环读取参数并赋值
while getopts ":a:b:c:d:e:f:" opt
do
    case $opt in
        a)
        id=$OPTARG
	echo "id:$OPTARG"
        ;;
        b)
        e_id=$OPTARG
        echo "e_id:$OPTARG"
        ;;
        c)
        name=$OPTARG
        echo "name:$OPTARG"
        ;;
        d)
        gender=$OPTARG
        echo "gender:$OPTARG"
        ;;
        e)
        ID_card=$OPTARG
        echo "ID_card:$OPTARG"
        ;;
        f)
        Tel=$OPTARG
        echo "Tel:$OPTARG"
        ;;
        ?)
        echo "input error"
        exit 1;;
    esac
done
if [ "$id" = "" ] || [ "$e_id" = "" ] || [ "$name" = "" ] || [ "$gender" = "" ] || [ "$ID_card" = "" ]|| [ "$Tel" = "" ];then
    help
    exit 1
else
    echo "------------输入参数成功--------------"
fi
values={\"id\":$id,\"e_id\":\"$e_id\",\"e_type\":\"基础标签\",\"label_value\":\"汉族,青年,中国江苏南京,B血型,方脸,工程师,未婚,近视,短发,中个\",\"entity_desc\":\"{\\\"姓名\\\":\\\"$name\\\",\\\"性别\\\":\\\"$gender\\\",\\\"证件号\\\":\\\"$ID_card\\\",\\\"联系方式\\\":\\\"$Tel\\\"}\",\"behavior_label\":\"昼伏夜出,通联,南京南站,涉毒\"}
#插数据模板
#curl -XPOST 'http://0.0.0.0:9200/entity_label1/entity_label1?pretty' -H 'Content-Type:application/json' -d '{"id":1,"e_id":"2","e_type":"基础标签","label_value":"汉族，青年，中国江苏南京，B血型，方脸，工程师，未婚，近视，短发，中个","entityy_desc":"{\"姓名\":\"3\",\"性别\":\"4\",\"证件号\":\"5\",\"联系方式\":\"6\"}"}'


echo "------------插入数据到es--------------"
echo  curl -XPOST "http://0.0.0.0:9200/entity_label1/entity_label1?pretty" -H "Content-Type:application/json" -d "$values"
echo "------------插入结果--------------"
#curl -XPOST "http://0.0.0.0:9200/entity_label1/entity_label1?pretty" -H "Content-Type:application/json" -d "$values"
if_else $?


echo "------------造右侧浮窗的信息--------------"
insert="INSERT INTO  data_radar.basic_e_person  VALUES ('$id', '$e_id', '$name', '$name', '$gender', 23, '身份证', '$ID_card', '19960324', '$Tel', '汉族', '江苏省南京市', '江苏省南京市', '中国', '江苏省', '南京市', '江宁区', '中新赛克', 'B', '普通话', '方脸', 185, 70.00, '工程师', '本科', '无党派', '未婚', '近视 短发', '2386afe4ba0d4e24bf1927c5d9fddfcf', 1551859600);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?


echo "------------个人详情---------------"
#个人详情->统计信息
insert="INSERT INTO data_radar.basic_statistic  VALUES ('$id', '$e_id', '12', '23', '32', '118', '汉族,青年,中国江苏南京,B血型,方脸,工程师,未婚,近视,短发,中个','昼伏夜出,通联,南京南站,涉毒', 'QQ群,微信群,传奇工会,热血传奇', '125/150611270', 6688);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#个人详情->线上动态
#两条动态
insert="INSERT INTO data_radar.dpi  VALUES ('1506112708', '$e_id', '$Tel', '466015061127087', '466115061127087', 'QQ', 1585101600, '460-00f-12312309', '119.05203', '32.0292', '江苏省南京市江宁区汤山街道南京汤山百联奥特莱斯广场','傅安平','$name'),('1506112708', '$e_id', '$Tel', '466015061127087', '466115061127087', 'Weixin', 1585015200, '460-00f-12312334','118.790165', '31.820050', '江苏省南京市南京南站','巴图尔','$name');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#个人详情->线下动态、 个人详情--科信_网安_技侦_DFX
insert="INSERT INTO data_radar.behavior_rp VALUES ('$id', '$e_id', '5', '南京南收费站', 'G450', 1585101600,  '南京南收费站', '卡口','static/js/component/machineRecord/app/P2P.svg');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#个人详情->雷达图
insert="INSERT INTO data_radar.bussiness  VALUES ('$e_id', 8, '涉毒'),('$e_id', 16, '涉恐'),('$e_id', 1, '涉藏'),('$e_id', 19, '涉政'),('$e_id', 10, '涉外'),('$e_id', 13 ,'其它');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?


echo "-----------轨迹图202003-23/24/25/26---------------"
insert="INSERT INTO safe_sjld.trs_dpi  VALUES ( 20, 19, 30, 28,1584928800000, 1584929100000, 1584929100000, 15061127, 8080, 15062234, 9999, '466015061127087', '$Tel', '466115061127087', 'zc', '460-00f-005e63e2', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.798172', '31.968729', '162.168.168.71', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200325',min=120)"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.trs_dpi VALUES ( 20, 19, 30, 28,1585015200000, 1585015500000, 1585015500000, 15061127, 8080, 15062234, 9999, '466015061127087', '$Tel', '466115061127087', 'zc', '460-00f-001', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.973487', '32.127984', '162.168.168.74', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200324',min=120);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.trs_dpi  VALUES ( 20, 19, 30, 28,1585101600000, 1584928800000, 1584929100000, 15061127, 8080, 15062234, 9999, '466015061127087', '$Tel', '466115061127087', 'zc', '460-00f-007', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.805969', '32.039888', '162.168.168.74', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200323',min=120);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO safe_sjld.trs_dpi  VALUES ( 20, 19, 30, 28,1585188000000, 1585188300000, 1585188300000, 15061127, 8080, 15062234, 9999, '466015061127087', '$Tel', '466115061127087', 'zc', '460-00f-032', 450, 5500003, 550, '1', 1, 'admin', 'admin', '118.8198899996', '31.9591667986', '162.168.168.74', 'http://162.168.168.71:9999/oceaneye', 'admin', '1506112708', 66, 'zc', 'weixin819440637', 'qq819440637', '819440637', 'fe80::ac77:7ccd:f9fb:e129%14', 'myzc', 'zxzc', 1585015200,DAY='20200326',min=120);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#-----关系图-----
echo "------------关系图--------------"
node="\"$e_id\",\"人员\",\"$name\",\"$name\",\"$gender\",\"23\",\"身份证\",\"$ID_card\",\"19960324\",\"$Tel\",\"汉族\",\"江苏省南京市\",\"江苏省南京市\",\"中国\",\"江苏省\",\"南京市\",\"江宁区\",\"中新赛克\",\"B\",\"普通话\",\"方脸\",\"185\",\"70.00\",\"工程师\",\"本科\",\"无党派\",\"未婚\",\"近视 短发\",\"$e_id\""
#停止neo4j
$neo4j_path/neo4j  stop
#备份库
rm -rf $pwd_path/graph_csv/graph.db.dump;$neo4j_path/neo4j-admin dump --database=graph.db --to=$pwd_path/graph_csv
#删除库
rm -rf $neo4j_path/../data/databases/graph.db
#修改csv数据
rm -rf $pwd_path/graph_csv/graph_new/*;cp $pwd_path/graph_csv/*.csv  $pwd_path/graph_csv/graph_new/
sed -i "/傅安和/d"   $pwd_path/graph_csv/graph_new/*.csv
sed -i "s/1001001/$e_id/g"  $pwd_path/graph_csv/graph_new/*.csv
echo "$node"
echo "$node" >>  $pwd_path/graph_csv/graph_new/basic_e_person.csv
#导入csv数据
$neo4j_path/neo4j-admin import --database=graph.db --mode=csv  --nodes "$pwd_path/graph_csv/graph_new/basic_e_location.csv" --nodes "$pwd_path/graph_csv/graph_new/basic_e_machine.csv" --nodes "$pwd_path/graph_csv/graph_new/basic_e_person.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_m_m_guishu.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_l_chuxian.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_m_guishu.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_qinshu.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tonglian.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongshi.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongxiang.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongxing.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongxue.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongzhu.csv" --delimiter=',' --ignore-duplicate-nodes=true --ignore-missing-nodes=true --ignore-extra-columns=true
#启动neo4j
$neo4j_path/neo4j  start
echo "------------end--------------"
