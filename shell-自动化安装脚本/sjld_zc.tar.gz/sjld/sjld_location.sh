#!/bin/bash

#固定参数
mysql_host="127.0.0.1"
mysql_port="3306"
mysql_user="rhino"
mysql_passwd="rhino"
mysql_path="/home/rhino/mysql-5.6.25-linux-x86_64/bin/mysql"

pwd_path=$(cd `dirname $0`; pwd)
neo4j_path="/home/rhino/neo4j-community-3.4.7/bin"
#函数:错误执行脚本打印help帮助信息
help()
{
cat<<HELP
#-----------------------------------------------------------------------------------#
###使用说明###

说明:

./sjld_location.sh -a id  -d  e_id((300开头) )  -c 地名  -d  地址  -e  经纬度

样例:

./sjld_location.sh    -a  1001  -b   300101 -c 夫子庙 -d  江苏省南京市秦淮区夫子庙景区贡院街152号  -e  118.804819,32.031807
#-----------------------------------------------------------------------------------#
HELP
}

#函数:判断上条命令是否执行成功
if_else()
{
    if [ $1 = 0 ];then
        echo "succeed"
    else
        echo "failed"
        exit 1
    fi
}

#循环读取参数并赋值
while getopts ":a:b:c:d:e:" opt
do
    case $opt in
        a)
        id=$OPTARG
        echo "id:$OPTARG"
        ;;
        b)
        e_id=$OPTARG
        echo "e_id:$OPTARG"
        ;;
        c)
        name=$OPTARG
	echo "name:$OPTARG"
        ;;
        d)
        add=$OPTARG
        echo "add:$OPTARG"
        ;;
        e)
        location=$OPTARG
        echo "location:$OPTARG"
        ;;
        ?)
        echo "input error"
        exit 1;;
    esac
done
if  [ "$id" = "" ] || [ "$e_id" = "" ] || [ "$name" = "" ] || [ "$add" = "" ] || [ "$location" = "" ];then
    help
    exit 1
else
    echo "------------输入参数成功--------------"
fi
values={\"id\":$id,\"e_id\":\"$e_id\",\"e_type\":\"基础标签\",\"label_value\":\"$name,公共场所\",\"location\":[$location],\"geohash\":\"wtswhzp4\",\"entity_desc\":\"{\\\"地名\\\":\\\"$name\\\",\\\"类型\\\":\\\"$name\\\",\\\"地址\\\":\\\"$add\\\"}\"}
#插数据模板
#curl -XPOST http://0.0.0.0:9200/entity_label1/entity_label1?pretty -H Content-Type:application/json -d  '{"id":666,"e_id":"300666","e_type":"基础标签","label_value":"景区,夫子庙","location":[118.804819,32.031807],"geohash":"wtswhzp4","entity_desc":"{\"地名\":\"夫子庙\",\"类型\":\"景区\",\"地址\":\"江苏省南京市秦淮区夫子庙景区贡院街152号\"}"}'

echo "------------插入数据到es--------------"
echo  curl -XPOST "http://0.0.0.0:9200/entity_label1/entity_label1?pretty" -H "Content-Type:application/json" -d "$values"
echo "------------插入结果--------------"
curl -XPOST "http://0.0.0.0:9200/entity_label1/entity_label1?pretty" -H "Content-Type:application/json" -d "$values"
if_else $?


lng=`echo $location | cut -d ',' -f 1`
lat=`echo $location | cut -d ',' -f 2`
echo "------------造右侧浮窗的信息--------------"
insert="INSERT INTO  data_radar.basic_e_location  VALUES ('$id', '$e_id', '$name', '公共场所', '$lng', '$lat','wtswhzp4', '$add', '15061127087', 'admin', 1551859600);"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#-----关系图-----
echo "------------关系图--------------"
node="\"$e_id\",\"位置\",\"$name\",\"公共场所\",\"$lng\",\"$lat\",\"wtswhzp4\",\"$add\",\"15061127087\",\"$e_id\""
#停止neo4j
$neo4j_path/neo4j  stop
#备份库
rm -rf $pwd_path/graph_csv/graph.db.dump;$neo4j_path/neo4j-admin dump --database=graph.db --to=$pwd_path/graph_csv
#删除库
rm -rf $neo4j_path/../data/databases/graph.db
#修改csv数据
rm -rf $pwd_path/graph_csv/graph_new/basic_e_location.csv;cp $pwd_path/graph_csv/basic_e_location.csv  $pwd_path/graph_csv/graph_new/
sed -i "/3003003/d"   $pwd_path/graph_csv/graph_new/basic_e_location.csv
sed -i "s/3003003/$e_id/g"  $pwd_path/graph_csv/graph_new/*.csv
echo "$node"
echo "$node" >>  $pwd_path/graph_csv/graph_new/basic_e_location.csv
#导入csv数据
$neo4j_path/neo4j-admin import --database=graph.db --mode=csv  --nodes "$pwd_path/graph_csv/graph_new/basic_e_location.csv" --nodes "$pwd_path/graph_csv/graph_new/basic_e_machine.csv" --nodes "$pwd_path/graph_csv/graph_new/basic_e_person.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_m_m_guishu.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_l_chuxian.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_m_guishu.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_qinshu.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tonglian.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongshi.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongxiang.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongxing.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongxue.csv" --relationships "$pwd_path/graph_csv/graph_new/relation_p_p_tongzhu.csv" --delimiter=',' --ignore-duplicate-nodes=true --ignore-missing-nodes=true --ignore-extra-columns=true
#启动neo4j
$neo4j_path/neo4j  start
echo "------------end--------------"
