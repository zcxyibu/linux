#!/bin/bash

#固定参数
mysql_host="127.0.0.1"
mysql_port="3306"
mysql_user="rhino"
mysql_passwd="rhino"
mysql_path="/home/rhino/mysql-5.6.25-linux-x86_64/bin/mysql"

pwd_path=$(cd `dirname $0`; pwd)
neo4j_path="/home/rhino/neo4j-community-3.4.7/bin"

#函数:判断上条命令是否执行成功
if_else()
{
    if [ $1 = 0 ];then
        echo "succeed"
    else
        echo "failed"
        exit 1
    fi
}

#版本1
#dass
: '
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "drop database daas;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "create database daas;"
if_else $?
echo "Please wait about 3 minutes..."
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/daas.sql
if_else $?
'

#版本2
#: '
#########数据处理########
echo "---数据处理定义---"
#删除流程
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.dme_process_definition WHERE 1;"
if_else $?
#删除左侧目录
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.dme_business_model  WHERE 1;"
if_else $?
#添加左侧目录
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/dme_business_model.sql
if_else $?
#添加流程
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/dme_process_definition.sql
if_else $?

echo "---策略调度管理---"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.dme_quartz_definition WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/dme_quartz_definition.sql
if_else $?

#i#######数据运维#########
echo "---页面实时预警---"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.daas_warning_page_info WHERE 1;"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.daas_warning_rule WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/daas_warning_page_info.sql
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/daas_warning_rule.sql
if_else $?

echo "---生命周期管理---"
#HDFS
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.dme_partitioned_management WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/dme_partitioned_management.sql
if_else $?
#HDFSDIR
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.dme_hdfsdir_ageing_management WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/dme_hdfsdir_ageing_management.sql
if_else $?
#HBASE
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.dme_hbaseageing_manage  WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/dme_hbaseageing_manage.sql
if_else $?
#HIVE
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.dme_hive_ageing_management  WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/dme_hive_ageing_management.sql
if_else $?

echo "---数据运维报表---"
#数据质量报表
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.source_quality_result_info WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/source_quality_result_info.sql
if_else $?


########数据治理#########
echo "---数据分级---"
#数据分级
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.daas_classfi_tree WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/daas_classfi_tree.sql
if_else $?

echo "---标签管理---"
#标签画像
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.daas_data_label_portrait WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/daas_data_label_portrait.sql
if_else $?

echo "---模型管理---"
#训练数据管理
#目录
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.data_set_train WHERE 1;"
if_else $?
#内容
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.data_set_category WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/data_set_category.sql
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/data_set_train.sql
if_else $?

echo "---数据质量管理---"
#质量知识库管理
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.daas_quality_knowledge WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/daas_quality_knowledge.sql
if_else $?


########数据接入#########
echo "---连接管理---"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.conn_param_list WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.daas_conn_tree WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/daas_conn_tree.sql
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/conn_param_list.sql
if_else $?
echo "---连接管理---"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.daas_data_set_tree WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/daas_data_set_tree.sql
if_else $?

echo "---数据对账---"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM shark.data_reconciliation_success_log WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM shark.data_statement WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  shark<$pwd_path/sql/data_statement.sql
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  shark<$pwd_path/sql/data_reconciliation_success_log.sql
if_else $?

#######数据组织#########
echo "---数据组织---"
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "DELETE FROM daas.daas_organize_dataresource WHERE 1;"
if_else $?
"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd"  daas<$pwd_path/sql/daas_organize_dataresource.sql
if_else $?
