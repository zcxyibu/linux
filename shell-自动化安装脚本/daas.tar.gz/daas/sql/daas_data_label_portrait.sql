/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 03/04/2020 10:17:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for daas_data_label_portrait
-- ----------------------------
DROP TABLE IF EXISTS `daas_data_label_portrait`;
CREATE TABLE `daas_data_label_portrait`  (
  `template_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '模板名称',
  `label_items` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签项',
  `label_items_value` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标签项值,存储的是',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间(YYYYMMDDhhmmss)',
  `create_user` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间(YYYYMMDDhhmmss)',
  `update_user` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`template_name`, `label_items`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '标签画像' ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of daas_data_label_portrait
-- ----------------------------
INSERT INTO `daas_data_label_portrait` VALUES ('人员标签', '2974aed720e74c50971ec84d9603533b-宗教信仰', '06afdf4cd0724d5eb8ba9b06e4250444-佛教', '2020-04-03 10:08:38', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('人员标签', '39142f57157d449983ace8d1b75e13d3-民族', '1f1871d6ea204f0489b178791f497a47-朝鲜族', '2020-04-03 10:08:38', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '人员身份', '公司职员', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '兵役状况代码', '其他', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '出行方式特征', '飞机', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '国籍', '中国', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '婚姻状况', '再婚', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '宗教信仰', '佛教', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '常去境外地', '首尔', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '常访问活动场所特征', '休闲健身,医疗', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '操作系统类型', 'window', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '最新出现地', '北京市', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '最高学历', '硕士研究生毕业', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '机动车号牌种类代码', '小型汽车号牌', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '机动车状态代码', '事故逃逸', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '机动车能源种类代码', '液化石油气', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '机动车车身颜色代码', '白', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '机动车车辆类型代码', 'N1类车辆', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '民族', '汉族', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '涉经济犯特征标签', '受贿', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '特殊专长', '解剖', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '社会关系', '同学,同事,师生,朋友,师徒,校友', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '经常来往地', '保定市,南通市,北京市,南京市', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '网络关系', '微博好友,QQ好友,钉钉好友,微信好友', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '职业类别', '医药卫生保健', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '设备颜色代码', '蓝', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '身材特征标签', '特瘦', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '身高', '中等', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '车辆品牌', '别克', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '通联关系', '微博,QQ,电话,微信,短信,钉钉', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('多组标签组成画像', '频繁来往人员类型', '医生', '2019-09-06 10:14:15', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '人员身份', '学生', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '健康状况标签', '亚健康状态,健康状态', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '兵役状况代码', '其他,未服兵役', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '出行方式特征', '飞机,火车,汽车', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '国籍', '中国', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '婚姻状况', '未婚', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '宗教信仰', '其他', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '常用证件类型', '身份证', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '常访问活动场所特征', '购物,公共娱乐,餐饮', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '年龄段', '青年', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '性别', '女性,男性', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '政治面貌', '群众,共青团员,中共党员', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '最高学历', '普通高中毕业,大学专科毕业', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '特殊专长', '打字,计算机技术,其他特长,外语,化妆', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '社会关系', '同学,师生,校友', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '网络关系', '微博好友,YY语音好友,QQ好友,微信好友,贴吧好友,人人网', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '身材特征标签', '矮胖,特瘦,高胖,偏胖,中等,特胖,偏瘦', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '身高', '161到170cm,181到190cm,171到180cm', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '通联关系', '微博,QQ,电话,邮箱,贴吧,旺旺,MSN,YY语音,微信,短信,信件,钉钉,FastMsg,传真,人人网,飞信', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('大学生画像', '频繁来往人员类型', '学生', '2019-09-19 15:51:05', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('实体标签', '9f6bf0a3e95b44a087907b278a1b2d83-标签项', '51d933b2479347b587334acfbce503e3-长居地址', '2020-04-03 10:12:29', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('惯偷人群', '性别', '男equal', '2019-08-12 09:25:09', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('惯偷人群', '特殊专长', '潜水', '2019-08-12 09:25:09', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('惯偷人群', '身高', '极高', '2019-08-12 09:25:09', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '人员身份', '公司职员', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '兵役状况代码', '未服兵役', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '国籍', '中国', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '婚姻状况', '离异', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '宗教信仰', '佛教', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '常去境外地', '新义州', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '常访问活动场所特征', '危险品销售、储存', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '性别', '男equal', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '最高学历', '博士研究生肄业', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '民族', '鄂伦春族', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '涉经济犯特征标签', '虚假广告', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '特殊专长', '计算机技术', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('涉毒人员', '职业类别', 'IT业', '2019-09-03 19:29:59', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('物品标签', '4cd3f2e1c9dd4dd590682d75016496cd-车辆品牌', '1a241af812c44d39bd37268516a229c3-宝马', '2020-04-03 10:11:31', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('物品标签', '7b5ff03eeccd4716b69db469ed23e7f3-机动车能源种类代码', '30140ee5642449fab34aa89af29a3dea-汽油', '2020-04-03 10:11:31', 'admin', NULL, NULL);
INSERT INTO `daas_data_label_portrait` VALUES ('物品标签', '9af0cf83b7724c859ce451564c5e1a9c-最新出现地', 'ce78bf23764d4d2697e3ee7c85202050-南京', '2020-04-03 10:11:31', 'admin', NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
