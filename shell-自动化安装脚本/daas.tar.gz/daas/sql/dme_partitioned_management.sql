/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 02/04/2020 19:19:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for dme_partitioned_management
-- ----------------------------
DROP TABLE IF EXISTS `dme_partitioned_management`;
CREATE TABLE `dme_partitioned_management`  (
  `Id` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'uuid',
  `Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '老化策略名,组里必须唯一.',
  `DbName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '库名',
  `TbName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '表名,分区列信息必须含有day.',
  `Day` int(11) NOT NULL,
  `RefrigerationDay` int(11) NULL DEFAULT NULL,
  `Formatter` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'yyyyMMdd',
  `CreateUser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '创建者',
  `CreateTime` datetime(0) NOT NULL COMMENT '创建时间',
  `UpdateUser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `UpdateTime` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `TimePartition` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '时间分区',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of dme_partitioned_management
-- ----------------------------
INSERT INTO `dme_partitioned_management` VALUES ('2526373f36wr26wr322223', 'HDFS老化', 'database', 'daas', 12, 0, 'yyyyMMdd', 'admin', '2019-09-03 14:44:56', 'admin', '2019-09-30 14:45:04', 'day');

SET FOREIGN_KEY_CHECKS = 1;
