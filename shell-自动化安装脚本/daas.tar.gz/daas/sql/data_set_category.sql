/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 03/04/2020 09:29:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for data_set_category
-- ----------------------------
DROP TABLE IF EXISTS `data_set_category`;
CREATE TABLE `data_set_category`  (
  `id` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据集分类id',
  `name` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据集分类名称',
  `pid` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '训练数据集分类' ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of data_set_category
-- ----------------------------
INSERT INTO `data_set_category` VALUES ('001', '训练数据集分类', '0', NULL);
INSERT INTO `data_set_category` VALUES ('002', '反扒', '001', NULL);
INSERT INTO `data_set_category` VALUES ('003', '侦查训练', '001', NULL);
INSERT INTO `data_set_category` VALUES ('004', '自然语义训练', '001', NULL);
INSERT INTO `data_set_category` VALUES ('005', '评分训练', '001', NULL);

SET FOREIGN_KEY_CHECKS = 1;
