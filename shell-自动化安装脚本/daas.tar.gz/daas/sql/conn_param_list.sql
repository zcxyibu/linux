/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 03/04/2020 10:51:02
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for conn_param_list
-- ----------------------------
DROP TABLE IF EXISTS `conn_param_list`;
CREATE TABLE `conn_param_list`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `connName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `connTag` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `busiType` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `connType` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `port` int(11) NULL DEFAULT NULL,
  `userName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `param1` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `anonymous` tinyint(1) NULL DEFAULT NULL,
  `groupUser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tree_ids` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '树的pids和id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 74 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of conn_param_list
-- ----------------------------
INSERT INTO `conn_param_list` VALUES (1, '本地HDFS连接', '用于连接本地HDFS系统', '分布式文件系统', 'HDFS', '', NULL, '', '', '', NULL, 'admin', '7d5cd2efdferfa34qdc5r5dsswsfeecb,13b693365af44c6792ef5bbb0fc941df');
INSERT INTO `conn_param_list` VALUES (58, 'SFTP连接', '远程文件连接', '远程文件服务器', 'sftp', '10.45.150.120', 22, 'rhino', 'rhino@123', '根目录:', 0, 'admin', '8c7c9a7c49894c5abdf7c7171e3403fb,13b693365af44c6792ef5bbb0fc941df');
INSERT INTO `conn_param_list` VALUES (59, 'FTP连接', '本地ftp连接', '远程文件服务器', 'ftp', '162.168.168.71', 21, 'rhino', 'rhino@123', '根目录:', 0, 'admin', '8c7c9a7c49894c5abdf7c7171e3403fb,13b693365af44c6792ef5bbb0fc941df');
INSERT INTO `conn_param_list` VALUES (60, 'mpp连接', '数据仓库连接', '数据仓库', 'mpp', '71.54.84.12', 5432, 'rhino', 'rhino', '初始数据库:daas_rk', 0, 'admin', '547a998d99cc44e5ac692e2c3deffc3a');
INSERT INTO `conn_param_list` VALUES (61, 'mysql连接', 'MySQL连接', '传统数据库', 'Mysql', '127.0.0.1', 3306, 'rhino', 'rhino', '', 0, 'admin', 'd18b7c30679e41e5bf30fa77d56a34de,13b693365af44c6792ef5bbb0fc941df');
INSERT INTO `conn_param_list` VALUES (62, 'hive连接', '数据仓库连接', '数据仓库', 'sparksql2', '10.45.150.120', 10000, 'rhino', 'rhino', '', 0, 'admin', '547a998d99cc44e5ac692e2c3deffc3a');
INSERT INTO `conn_param_list` VALUES (68, 'es连接', '数据仓库连接', '数据仓库', 'ElasticSearch', '162.168.2.168', 9200, '', '', '数据库:', 1, 'admin', '547a998d99cc44e5ac692e2c3deffc3a');
INSERT INTO `conn_param_list` VALUES (72, 'MySQL连接', 'MySQL连接', '传统数据库', 'Mysql', '71.54.84.12', 3306, 'rhino', 'rhino', '', 0, 'admin', 'd18b7c30679e41e5bf30fa77d56a34de,13b693365af44c6792ef5bbb0fc941df');
INSERT INTO `conn_param_list` VALUES (73, 'neo4j图数据库连接', '图数据库连接', '图数据库', 'neo4j', '127.0.0.1', 7474, 'admin', '123456', '', 0, 'admin', '2a0b5661d1ec40e4b5ac739293ccef85');

SET FOREIGN_KEY_CHECKS = 1;
