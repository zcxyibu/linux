/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 02/04/2020 19:20:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for dme_hive_ageing_management
-- ----------------------------
DROP TABLE IF EXISTS `dme_hive_ageing_management`;
CREATE TABLE `dme_hive_ageing_management`  (
  `Id` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'uuid',
  `Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '老化策略名,组里必须唯一.',
  `DbName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '库名',
  `TbName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '表名,分区列信息必须含有day.',
  `Day` int(11) NOT NULL,
  `RefrigerationDay` int(11) NULL DEFAULT NULL,
  `Formatter` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'yyyyMMdd',
  `CreateUser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '创建者',
  `CreateTime` datetime(0) NOT NULL COMMENT '创建时间',
  `UpdateUser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `UpdateTime` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `TimePartition` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '时间分区',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of dme_hive_ageing_management
-- ----------------------------
INSERT INTO `dme_hive_ageing_management` VALUES ('321321w3214151883', 'HIVE老化策略', 'databash', 'daas', 21, 1, 'yyyyMMdd', 'admin', '2019-09-23 14:51:04', 'admin', '2019-09-30 14:51:07', 'day');

SET FOREIGN_KEY_CHECKS = 1;
