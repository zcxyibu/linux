/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.58.47
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 10.45.150.122:3306
 Source Schema         : shark

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 03/04/2020 10:45:39
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for data_statement
-- ----------------------------
DROP TABLE IF EXISTS `data_statement`;
CREATE TABLE `data_statement`  (
  `sjtgfdzdbh` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '数据提供方对账单编号',
  `sjjrfdzdbh` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '数据接入方对账单编号',
  `sjtgfbh` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据提供方编号',
  `sjjrfbh` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据接入方编号',
  `sjzybh` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据资源编号',
  `sjts` int(11) NOT NULL COMMENT '数据条数',
  `sjzw` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据指纹',
  `sjzwlx` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据指纹类型',
  `sjdx` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据大小',
  `sjqsbh` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据起始编号',
  `sjjwbh` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据结尾编号',
  `sjlyccwz` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据来源存储位置',
  `zdzt` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '账单状态',
  `scsbzdh` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '上次失败账单号',
  `fssj` datetime(0) NOT NULL COMMENT '发送时间',
  `dzsj` datetime(0) NOT NULL COMMENT '对账时间',
  `dzff` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '对账方法',
  `dzdlx` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '对账单类型',
  `dzjgms` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '对账结果描述',
  `sjtgfgly` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '数据提供方管理员',
  `sjjrfgly` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '数据接入方管理员',
  `lysjglylxdh` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '来源数据管理员联系电话',
  `sjjrfglylxdh` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '数据接入方管理员联系电话',
  `sjlymc` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据来源名称',
  `sjlylx` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据来源类型',
  `dztj` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `process_ins_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '流程实例ID'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of data_statement
-- ----------------------------
INSERT INTO `data_statement` VALUES ('DZT-123456789012-00001-20191217-00000001', NULL, 'DP-123456789012-00001', 'DP-098765432109-00001', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '未对账', '', '2019-12-17 09:58:00', '2019-12-17 09:58:00', '即时对账', '数据提供方对账单', '', '王二小', NULL, '17368689893', NULL, '数据来源1', '数据库', NULL, 'bc718d69eed644db9918c1eed84a7e43');
INSERT INTO `data_statement` VALUES (NULL, '20191218-00000002', 'DP-123456789012-00001', '', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '对账成功', '', '2019-12-17 09:58:00', '2019-12-18 15:45:00', '即时对账', '数据接入方对账单', '', NULL, '', NULL, '', '数据来源1', '数据库', NULL, 'bc718d69eed644db9918c1eed84a7e43');
INSERT INTO `data_statement` VALUES ('DZT-123456789012-00001-20191217-00000001', NULL, 'DP-123456789012-00001', 'DP-098765432109-00001', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '未对账', '', '2019-12-17 09:58:00', '2019-12-17 09:58:00', '即时对账', '数据提供方对账单', '', '王二小', NULL, '17368689893', NULL, '数据来源1', '数据库', NULL, '6890285a81c84ced8f77a9fe8491eacf');
INSERT INTO `data_statement` VALUES (NULL, '20191218-00000003', 'DP-123456789012-00001', '', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '对账成功', '', '2019-12-17 09:58:00', '2019-12-18 15:47:00', '即时对账', '数据接入方对账单', '', NULL, '', NULL, '', '数据来源1', '数据库', NULL, '6890285a81c84ced8f77a9fe8491eacf');
INSERT INTO `data_statement` VALUES ('DZT-123456789012-00001-20191217-00000001', NULL, 'DP-123456789012-00001', 'DP-098765432109-00001', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '未对账', '', '2019-12-17 09:58:00', '2019-12-17 09:58:00', '即时对账', '数据提供方对账单', '', '王二小', NULL, '17368689893', NULL, '数据来源1', '数据库', NULL, '4959cdbeaa2d4fa894a0a5bbac65f397');
INSERT INTO `data_statement` VALUES (NULL, '20191218-00000004', 'DP-123456789012-00001', '', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '对账成功', '', '2019-12-17 09:58:00', '2019-12-18 15:49:00', '即时对账', '数据接入方对账单', '', NULL, '', NULL, '', '数据来源1', '数据库', NULL, '4959cdbeaa2d4fa894a0a5bbac65f397');
INSERT INTO `data_statement` VALUES ('DZT-123456789012-00001-20191217-00000001', NULL, 'DP-123456789012-00001', 'DP-098765432109-00001', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '未对账', '', '2019-12-17 09:58:00', '2019-12-17 09:58:00', '即时对账', '数据提供方对账单', '', '王二小', NULL, '17368689893', NULL, '数据来源1', '数据库', NULL, '274be18555014eacbbf7699c7045e0a1');
INSERT INTO `data_statement` VALUES (NULL, '20191218-00000005', 'DP-123456789012-00001', '', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '对账成功', '', '2019-12-17 09:58:00', '2019-12-18 15:50:00', '即时对账', '数据接入方对账单', '', NULL, '', NULL, '', '数据来源1', '数据库', NULL, '274be18555014eacbbf7699c7045e0a1');
INSERT INTO `data_statement` VALUES ('DZT-123456789012-00001-20191217-00000002', NULL, 'DP-123456789012-00001', 'DP-098765432109-00001', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '未对账', '', '2019-12-17 09:59:00', '2019-12-17 09:59:00', '即时对账', '数据提供方对账单', '', '王二小', NULL, '17368689893', NULL, '数据来源1', '数据库', NULL, '274be18555014eacbbf7699c7045e0a1');
INSERT INTO `data_statement` VALUES (NULL, '20191218-00000006', 'DP-123456789012-00001', '', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '对账成功', '', '2019-12-17 09:59:00', '2019-12-18 15:50:00', '即时对账', '数据接入方对账单', '', NULL, '', NULL, '', '数据来源1', '数据库', NULL, '274be18555014eacbbf7699c7045e0a1');
INSERT INTO `data_statement` VALUES ('DZT-123456789012-00001-20191217-00000001', NULL, 'DP-123456789012-00001', 'DP-098765432109-00001', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '未对账', '', '2019-12-17 09:58:00', '2019-12-17 09:58:00', '即时对账', '数据提供方对账单', '', '王二小', NULL, '17368689893', NULL, '数据来源1', '数据库', NULL, 'b4356cf927a64968acd1250c5b305a34');
INSERT INTO `data_statement` VALUES (NULL, '20191218-00000007', 'DP-123456789012-00001', '', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '对账成功', '', '2019-12-17 09:58:00', '2019-12-18 15:52:00', '即时对账', '数据接入方对账单', '', NULL, '', NULL, '', '数据来源1', '数据库', NULL, 'b4356cf927a64968acd1250c5b305a34');
INSERT INTO `data_statement` VALUES ('DZT-123456789012-00001-20191217-00000002', NULL, 'DP-123456789012-00001', 'DP-098765432109-00001', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '未对账', '', '2019-12-17 09:59:00', '2019-12-17 09:59:00', '即时对账', '数据提供方对账单', '', '王二小', NULL, '17368689893', NULL, '数据来源1', '数据库', NULL, 'b4356cf927a64968acd1250c5b305a34');
INSERT INTO `data_statement` VALUES (NULL, '20191218-00000008', 'DP-123456789012-00001', '', '123', 6, '40035863bd49bd7ace667694296cb568', 'MD5', '730bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/test20190828', '对账成功', '', '2019-12-17 09:59:00', '2019-12-18 15:52:00', '即时对账', '数据接入方对账单', '', NULL, '', NULL, '', '数据来源1', '数据库', NULL, 'b4356cf927a64968acd1250c5b305a34');
INSERT INTO `data_statement` VALUES ('DZT-123456789012-00001-20191121-00000001', NULL, 'DP-123456789012-00001', 'DP-098765432109-00001', '123', 4, '987e39bb21ff42e2af71bece655f966c', 'MD5', '131bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/wyj02', '未对账', '', '2019-11-21 16:10:00', '2019-11-21 16:10:00', '即时对账', '数据提供方对账单', '', '王二小', NULL, '17368689893', NULL, '数据来源1', '数据库', NULL, '90da7747c9944b3db9034834b74098fc');
INSERT INTO `data_statement` VALUES (NULL, '20200110-00000035', 'DP-123456789012-00001', '', '123', 4, '987e39bb21ff42e2af71bece655f966c', 'MD5', '131bytes', '', '', 'jdbc:mysql://10.45.150.120:3306/wangyongjian/wyj02', '对账成功', '', '2019-11-21 16:10:00', '2020-01-10 10:58:00', '即时对账', '数据接入方对账单', '', NULL, '', NULL, '', '数据来源1', '数据库', NULL, '90da7747c9944b3db9034834b74098fc');

SET FOREIGN_KEY_CHECKS = 1;
