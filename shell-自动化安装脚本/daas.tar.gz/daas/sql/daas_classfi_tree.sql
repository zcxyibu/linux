/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 03/04/2020 09:28:03
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for daas_classfi_tree
-- ----------------------------
DROP TABLE IF EXISTS `daas_classfi_tree`;
CREATE TABLE `daas_classfi_tree`  (
  `id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pid` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `rpid` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pids` varchar(2500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` tinyint(1) NULL DEFAULT NULL,
  `rule` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_person` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `update_person` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  `enable_flag` tinyint(1) NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `rank` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of daas_classfi_tree
-- ----------------------------
INSERT INTO `daas_classfi_tree` VALUES ('00f87asdfff74a2c9f36be19ad866c3c', '数据分级', '0', '00f87asdfff74a2c9f36be19ad866c3c', '0', 0, NULL, 'admin', NULL, '2019-03-11 15:30:51', NULL, NULL, NULL, '0');
INSERT INTO `daas_classfi_tree` VALUES ('084b78e4027f4a758bc683d9a1418242', '敏感语音', 'ac8e23754043459e8e12b5bff3a167d4', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ac8e23754043459e8e12b5bff3a167d4', 2, NULL, NULL, NULL, '2019-08-31 10:38:26', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('224eb692ca574f0f8b8d36c41a80f167', '敏感阈值规则', 'ac8e23754043459e8e12b5bff3a167d4', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ac8e23754043459e8e12b5bff3a167d4', 2, NULL, NULL, NULL, '2019-08-31 10:38:47', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('224eb692ca574f0f8b8d36c41a80f16h', '敏感阈值规则', 'ef177e1ecb9443e6819daf2272175895', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ef177e1ecb9443e6819daf2272175895', 2, NULL, NULL, NULL, '2019-08-31 10:38:47', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('24986a2be32841ff837cc40ae19f1f8e', '敏感身份', '2b2058d4c7e543a8a986b8656b1baefa', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,2b2058d4c7e543a8a986b8656b1baefa', 2, NULL, NULL, NULL, '2019-08-12 16:12:51', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('2b2058d4c7e543a8a986b8656b1baefa', '敏感身份', '00f87asdfff74a2c9f36be19ad866c3c', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c', 1, NULL, 'admin', NULL, '2019-08-12 16:12:09', NULL, 1, NULL, '1');
INSERT INTO `daas_classfi_tree` VALUES ('31f704ea76b048d7aaa0402439413952', '敏感身份规则', 'ac8e23754043459e8e12b5bff3a167d4', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ac8e23754043459e8e12b5bff3a167d4', 2, NULL, NULL, NULL, '2019-08-31 10:35:03', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('31f704ea76b048d7aaa040243941395h', '敏感身份规则', 'ef177e1ecb9443e6819daf2272175895', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ef177e1ecb9443e6819daf2272175895', 2, NULL, NULL, NULL, '2019-08-31 10:35:03', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('46505c7ec632401c8d5bff4c43f9455d', '数据级别3', '00f87asdfff74a2c9f36be19ad866c3c', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c', 1, NULL, 'admin', NULL, '2019-08-31 10:34:02', NULL, 1, NULL, '1');
INSERT INTO `daas_classfi_tree` VALUES ('5bf11d7b048345db8fa9aeadf569346a', '敏感关键词规则', 'ac8e23754043459e8e12b5bff3a167d4', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ac8e23754043459e8e12b5bff3a167d4', 2, NULL, NULL, NULL, '2019-08-31 10:35:31', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('5bf11d7b048345db8fa9aeadf569346h', '敏感关键词规则', 'ef177e1ecb9443e6819daf2272175895', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ef177e1ecb9443e6819daf2272175895', 2, NULL, NULL, NULL, '2019-08-31 10:35:31', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('a6c999865d1b4993a6e0f0cae2bdf723', '其他敏感信息规则', 'ac8e23754043459e8e12b5bff3a167d4', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ac8e23754043459e8e12b5bff3a167d4', 2, NULL, NULL, NULL, '2019-08-31 10:39:19', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('a6c999865d1b4993a6e0f0cae2bdf72h', '其他敏感信息规则', 'ef177e1ecb9443e6819daf2272175895', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ef177e1ecb9443e6819daf2272175895', 2, NULL, NULL, NULL, '2019-08-31 10:39:19', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('ac8e23754043459e8e12b5bff3a167d4', '数据级别1', '00f87asdfff74a2c9f36be19ad866c3c', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c', 1, NULL, 'admin', 'admin', '2019-08-30 15:56:13', '2019-08-31 10:33:27', 1, NULL, '1');
INSERT INTO `daas_classfi_tree` VALUES ('b6f9fcceb6c24995acbeb13dcd108f33', '关键字', '00f87asdfff74a2c9f36be19ad866c3c', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c', 1, NULL, 'admin', NULL, '2019-08-13 09:51:53', NULL, 1, NULL, '1');
INSERT INTO `daas_classfi_tree` VALUES ('c69af8954e7c4d51b7b09ae596886e67', '关键字规则', 'b6f9fcceb6c24995acbeb13dcd108f33', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,b6f9fcceb6c24995acbeb13dcd108f33', 2, NULL, NULL, NULL, '2019-08-13 09:52:32', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('cbaf2b9f1b374c4bb073eebd200bc607', '敏感图片规则', 'ac8e23754043459e8e12b5bff3a167d4', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ac8e23754043459e8e12b5bff3a167d4', 2, NULL, NULL, NULL, '2019-08-31 10:37:50', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('cbaf2b9f1b374c4bb073eebd200bc60h', '敏感图片规则', 'ef177e1ecb9443e6819daf2272175895', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c,ef177e1ecb9443e6819daf2272175895', 2, NULL, NULL, NULL, '2019-08-31 10:37:50', NULL, 1, NULL, '2');
INSERT INTO `daas_classfi_tree` VALUES ('d59458bb725d4ccbb202e176f89eb175', '数据级别4', '00f87asdfff74a2c9f36be19ad866c3c', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c', 1, NULL, 'admin', NULL, '2019-08-31 10:34:10', NULL, 1, NULL, '1');
INSERT INTO `daas_classfi_tree` VALUES ('ef177e1ecb9443e6819daf2272175895', '数据级别2', '00f87asdfff74a2c9f36be19ad866c3c', NULL, '0,00f87asdfff74a2c9f36be19ad866c3c', 1, NULL, 'admin', NULL, '2019-08-31 10:33:56', NULL, 1, NULL, '1');

SET FOREIGN_KEY_CHECKS = 1;
