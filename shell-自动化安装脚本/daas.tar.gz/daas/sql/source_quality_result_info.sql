/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 02/04/2020 19:47:06
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for source_quality_result_info
-- ----------------------------
DROP TABLE IF EXISTS `source_quality_result_info`;
CREATE TABLE `source_quality_result_info`  (
  `processIns_id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '流程实例id',
  `process_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '流程名',
  `column_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '待评分列名称',
  `rule_name_des` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '规则名称',
  `rule_expression` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '规则表达式',
  `start_time` timestamp(0) NULL DEFAULT NULL COMMENT '评分开始时间',
  `end_time` timestamp(0) NULL DEFAULT NULL COMMENT '评分结束时间',
  `deal_result` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '处理结果，O为成功，E为失败',
  `total_count` bigint(20) NULL DEFAULT NULL COMMENT '检测数据条数',
  `fail_count` bigint(20) NULL DEFAULT NULL COMMENT '失败数据总数',
  `ruleId` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '预警规则id',
  `creator` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '当前登录用户名',
  `source_count` bigint(20) NULL DEFAULT NULL COMMENT '应读取记录数',
  `read_count` bigint(20) NULL DEFAULT NULL COMMENT '实际读取记录数',
  `data_resource_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '数据资源标识符',
  `data_item_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '数据项标识符',
  `start_readtime` timestamp(0) NULL DEFAULT NULL COMMENT '数据读取开始时间',
  `end_readtime` timestamp(0) NULL DEFAULT NULL COMMENT '数据读取结束时间',
  `quality_dimension` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '质量维度,包括记录完整性、格式有效性等',
  `quality_check_stage` int(2) NULL DEFAULT NULL COMMENT '质量核检阶段:0(数据探查)、1(数据读取)、2(数据清洗)、3(数据分发)、4(数据存储)'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '数据质量报表' ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of source_quality_result_info
-- ----------------------------
INSERT INTO `source_quality_result_info` VALUES ('da917412fea74fe0961194b109970881', '质量评分', 'age', 'rule1_value_valid', '(age>0)AND(age<100)', '2019-08-15 20:07:06', '2019-08-15 20:07:07', 'O', 2, 0, 'efaf7f500be0471285bcd85038b356ba', 'admin', 2, 2, 'R-000000000001-00000149', 'null', '2019-08-15 20:07:06', '2019-08-15 20:07:07', '值域有效性', 0);
INSERT INTO `source_quality_result_info` VALUES ('e5f0d6ee341343cea6d53deb37c0cc86', '质量评分', 'age', 'rule1_value_valid', '(age>0)AND(age<100)', '2019-08-15 20:07:33', '2019-08-15 20:07:33', 'O', 2, 0, 'efaf7f500be0471285bcd85038b356ba', 'admin', 2, 2, 'R-000000000001-00000149', 'null', '2019-08-15 20:07:33', '2019-08-15 20:07:33', '值域有效性', 0);
INSERT INTO `source_quality_result_info` VALUES ('13619ef874c045a2b5c01449fb2ae831', '质量评分', 'age', 'rule1_value_valid', '(age>0)AND(age<100)', '2019-08-15 20:07:36', '2019-08-15 20:07:37', 'O', 2, 0, 'efaf7f500be0471285bcd85038b356ba', 'admin', 2, 2, 'R-000000000001-00000149', 'null', '2019-08-15 20:07:36', '2019-08-15 20:07:37', '值域有效性', 0);

SET FOREIGN_KEY_CHECKS = 1;
