/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 02/04/2020 19:20:21
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for dme_hdfsdir_ageing_management
-- ----------------------------
DROP TABLE IF EXISTS `dme_hdfsdir_ageing_management`;
CREATE TABLE `dme_hdfsdir_ageing_management`  (
  `Id` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Day` int(11) NULL DEFAULT NULL,
  `Formatter` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `CreateUser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `CreateTime` datetime(0) NOT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `UpdateUser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `UpdateTime` datetime(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `Direction` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of dme_hdfsdir_ageing_management
-- ----------------------------
INSERT INTO `dme_hdfsdir_ageing_management` VALUES ('1234ed321e21e21421321', 'HDFS文件老化', 13, 'yyyyMMdd', 'admin', '2019-09-10 14:48:00', 'admin', '2019-09-25 14:48:11', '/hdfsOutput/wenjian/');

SET FOREIGN_KEY_CHECKS = 1;
