/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 02/04/2020 17:20:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for daas_warning_rule
-- ----------------------------
DROP TABLE IF EXISTS `daas_warning_rule`;
CREATE TABLE `daas_warning_rule`  (
  `id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `log_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `exp` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `push_mode` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `creator` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `send_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `topic` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tree_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `degree` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tree_pids` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of daas_warning_rule
-- ----------------------------
INSERT INTO `daas_warning_rule` VALUES ('044aaa6bfa1541f0b313d7fafc619663', '告警敏感词检测', '', ' appear(${col_02},\'big\',\'theory\')', 'page', '告警敏感词', 'admin', '2019-09-20 16:31:17', '', '', '', '4184575c690648bf8def24e3c9b69acd', '1', '0,00f77qcdfff74a2c9f43mn19ad866c3c');
INSERT INTO `daas_warning_rule` VALUES ('31fbf6a7128544aea36d37a300c17e03', '状态检测', '', 'statusChanged(status,3)', 'page', '通道或进程检测', 'admin', '2019-07-30 09:59:46', '', '', '', '0b6613f3c66945e687cdd75a2b2fad80', '1', '0,00f77qcdfff74a2c9f43mn19ad866c3c');
INSERT INTO `daas_warning_rule` VALUES ('d31ce441dbea4be9aa47c4f4cd48288e', '状态检测预警', '', 'statusChanged(status,3)', 'page', '无', 'admin', '2019-09-02 09:55:59', '', '', '', 'af12610864c44a16a7052650ed469718', '0', '0,00f77qcdfff74a2c9f43mn19ad866c3c');
INSERT INTO `daas_warning_rule` VALUES ('efaf7f500be0471285bcd85038b356ba', '数据质量检测', '', 'numberRecord(${fail_count}>3)', 'page', '数据质量检测', 'admin', '2019-07-30 10:07:43', '', '', '', '22332a4c49a54d0da761c041fc225091', '1', '0,00f77qcdfff74a2c9f43mn19ad866c3c');

SET FOREIGN_KEY_CHECKS = 1;
