/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.58.47
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 10.45.150.122:3306
 Source Schema         : shark

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 03/04/2020 10:46:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for data_reconciliation_success_log
-- ----------------------------
DROP TABLE IF EXISTS `data_reconciliation_success_log`;
CREATE TABLE `data_reconciliation_success_log`  (
  `process_ins_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '流程实例ID',
  `process_def_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '流程定义ID',
  `file_path` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '文件绝对路径',
  `provider_statement_num` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '提供方对账单编号',
  `access_statement_num` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '数据接入方对账单编号',
  `reconciliation_time` datetime(0) NOT NULL COMMENT '对账时间',
  `write_off_state` varchar(3) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '销账状态'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of data_reconciliation_success_log
-- ----------------------------
INSERT INTO `data_reconciliation_success_log` VALUES ('bc718d69eed644db9918c1eed84a7e43', 'sysgroup-admin-e3699b9ee5cc48feba17052d2f1bcbf0', 'hdfs://hacluster/tenant/saikedaas/data/test002/20191217095848_test20190828_0.parquet', 'DZT-123456789012-00001-20191217-00000001', '20191218-00000002', '2019-12-18 15:45:00', '已销账');
INSERT INTO `data_reconciliation_success_log` VALUES ('6890285a81c84ced8f77a9fe8491eacf', 'sysgroup-admin-e3699b9ee5cc48feba17052d2f1bcbf0', 'hdfs://hacluster/tenant/saikedaas/data/test002/20191217095848_test20190828_0.parquet', 'DZT-123456789012-00001-20191217-00000001', '20191218-00000003', '2019-12-18 15:47:00', '已销账');
INSERT INTO `data_reconciliation_success_log` VALUES ('4959cdbeaa2d4fa894a0a5bbac65f397', 'sysgroup-admin-e3699b9ee5cc48feba17052d2f1bcbf0', 'hdfs://hacluster/tenant/saikedaas/data/test002/20191217095848_test20190828_0.parquet', 'DZT-123456789012-00001-20191217-00000001', '20191218-00000004', '2019-12-18 15:49:00', '已销账');
INSERT INTO `data_reconciliation_success_log` VALUES ('274be18555014eacbbf7699c7045e0a1', 'sysgroup-admin-e3699b9ee5cc48feba17052d2f1bcbf0', 'hdfs://hacluster/tenant/saikedaas/data/test002/20191217095848_test20190828_0.parquet', 'DZT-123456789012-00001-20191217-00000001', '20191218-00000005', '2019-12-18 15:50:00', '已销账');
INSERT INTO `data_reconciliation_success_log` VALUES ('274be18555014eacbbf7699c7045e0a1', 'sysgroup-admin-e3699b9ee5cc48feba17052d2f1bcbf0', 'hdfs://hacluster/tenant/saikedaas/data/test002/20191217095908_test20190828_0.parquet', 'DZT-123456789012-00001-20191217-00000002', '20191218-00000006', '2019-12-18 15:50:00', '已销账');
INSERT INTO `data_reconciliation_success_log` VALUES ('b4356cf927a64968acd1250c5b305a34', 'sysgroup-admin-e3699b9ee5cc48feba17052d2f1bcbf0', 'hdfs://hacluster/tenant/saikedaas/data/test002/20191217095848_test20190828_0.parquet', 'DZT-123456789012-00001-20191217-00000001', '20191218-00000007', '2019-12-18 15:52:00', '已销账');
INSERT INTO `data_reconciliation_success_log` VALUES ('b4356cf927a64968acd1250c5b305a34', 'sysgroup-admin-e3699b9ee5cc48feba17052d2f1bcbf0', 'hdfs://hacluster/tenant/saikedaas/data/test002/20191217095908_test20190828_0.parquet', 'DZT-123456789012-00001-20191217-00000002', '20191218-00000008', '2019-12-18 15:52:00', '已销账');
INSERT INTO `data_reconciliation_success_log` VALUES ('90da7747c9944b3db9034834b74098fc', 'sysgroup-admin-d30eee217c96498bbf881586483ba075', 'hdfs://hacluster/tenant/saikedaas/data/sysgroup/admin/sw/sjdz/90da7747c9944b3db9034834b74098fc-e524e5ba2e224474be07f9b8f3d11dc9/20191121161016_wyj02_0.txt', 'DZT-123456789012-00001-20191121-00000001', '20200110-00000035', '2020-01-10 10:58:00', '已销账');

SET FOREIGN_KEY_CHECKS = 1;
