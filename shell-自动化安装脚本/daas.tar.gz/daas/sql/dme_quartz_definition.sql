/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 02/04/2020 15:05:26
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for dme_quartz_definition
-- ----------------------------
DROP TABLE IF EXISTS `dme_quartz_definition`;
CREATE TABLE `dme_quartz_definition`  (
  `JobID` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ID` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ProcessDefName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `JobName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Expression` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `DealResult` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `CreatePersion` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `CreateDate` datetime(0) NULL DEFAULT NULL,
  `UpdatePerson` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `UpdateDate` datetime(0) NULL DEFAULT NULL,
  `State` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Remarks` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Attributes` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `StrategyType` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`JobID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of dme_quartz_definition
-- ----------------------------
INSERT INTO `dme_quartz_definition` VALUES ('93a295dd91b749199bce97466070060e', 'sysgroup-admin-45cbbac35d7943529456e722a078ad82', '字典表转换流式', '字典转换流程策略', '0 0 0 */1 * ? *', NULL, 'admin', '2019-08-12 16:07:16', 'admin', '2019-09-03 16:56:32', 'S', '', '{\"executePeriod\":\"按天\",\"dayValue\":\"\",\"weekdayValue\":\"\",\"hourValue\":\"0\",\"minuteValue\":\"0\",\"secondValue\":\"0\",\"timePeriod\":\"1\"}', '周期执行');
INSERT INTO `dme_quartz_definition` VALUES ('93a295dd91b749199bce97466070060f', 'sysgroup-admin-25892bcffe1544e69874e2e990909cca', '数据打标', '数据打标', '0 0 1 */1 * ? *', '', 'admin', '2019-08-12 16:07:16', 'admin', '2019-09-03 16:56:32', 'S', '', '{\"executePeriod\":\"按天\",\"dayValue\":\"\",\"weekdayValue\":\"\",\"hourValue\":\"0\",\"minuteValue\":\"0\",\"secondValue\":\"0\",\"timePeriod\":\"1\"}', '周期执行');
INSERT INTO `dme_quartz_definition` VALUES ('a5641fc5e50540b9a8f3138e28828475', 'sysgroup-admin-ca3ba23e7b8245bc802c1cec732f33c8', '人员信息入原始库', '人员信息入原始库', '2 */1 * * * ? *', '', 'admin', '2019-08-06 15:49:12', 'admin', '2019-09-03 16:36:02', 'S', '', '{\"executePeriod\":\"按分\",\"dayValue\":\"\",\"weekdayValue\":\"\",\"hourValue\":\"\",\"minuteValue\":\"\",\"secondValue\":\"2\",\"timePeriod\":\"1\"}', '周期执行');
INSERT INTO `dme_quartz_definition` VALUES ('a5641fc5e50540b9a8f3138e2882847f', 'sysgroup-admin-7e13512b63204e1698350fe75f8dddc0', '原始数据集入原始库C', '原始数据集入原始库C', '2 */1 * * * ? *', NULL, 'admin', '2019-08-06 15:49:12', 'admin', '2019-09-03 16:36:02', 'S', '', '{\"executePeriod\":\"按分\",\"dayValue\":\"\",\"weekdayValue\":\"\",\"hourValue\":\"\",\"minuteValue\":\"\",\"secondValue\":\"2\",\"timePeriod\":\"1\"}', '周期执行');

SET FOREIGN_KEY_CHECKS = 1;
