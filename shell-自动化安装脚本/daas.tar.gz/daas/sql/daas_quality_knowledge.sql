/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 03/04/2020 09:29:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for daas_quality_knowledge
-- ----------------------------
DROP TABLE IF EXISTS `daas_quality_knowledge`;
CREATE TABLE `daas_quality_knowledge`  (
  `knowledgename` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '知识名称',
  `checkrule` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '检验规则',
  `associateprocess` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '关联流程',
  `creater` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `problemdesc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '问题描述',
  `id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'id',
  `associateprocessid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '流程id',
  `checkruleid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '质量规则id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of daas_quality_knowledge
-- ----------------------------
INSERT INTO `daas_quality_knowledge` VALUES ('知识图', 'rule1_value_valid', '图更新', '王大陆', '备注无', '知识图质量更新', '07139255-c9e1-4119-afa3-d279a27777a3', 'sysgroup-admin-d4987476ad2945e5bf18c61c730312ad', 'bb30de4c84314ebf9b22ab34031fe77f');
INSERT INTO `daas_quality_knowledge` VALUES ('主键唯一性质量', '主键唯一性规则', '数据分发算子流程', '周一围', '无', '数据分发主键唯一性', 'edb1c34b-f06a-43a0-a538-5a545e7f0091', 'sysgroup-admin-5c3abe0c0a1a4fa4905f48d70c858bc0', '2ebdb9eaa31a4d4b9686ada056a70cf3');
INSERT INTO `daas_quality_knowledge` VALUES ('接入及时性质量', '接入及时性', '原始数据集入原始库', '董文文', '无', '接入及时性质量', 'f3b7d9c4-f729-4f13-9ca0-722a5feb3de5', 'sysgroup-admin-900c5f09a6074d559938757283e0f04b', '228ec0cdad224eb29bf51d93e5a589e5');
INSERT INTO `daas_quality_knowledge` VALUES ('数据清洗质量', '逻辑合理性规则', '数据清洗流程', '王大地', '无', '数据清洗质量', 'f5d71281-a894-44c1-854f-11da80746913', 'sysgroup-admin-49f1e99cb652431baefa0a23e5f34ec3', '417ac4b2f2fe426bbec4c3b6dd796546');

SET FOREIGN_KEY_CHECKS = 1;
