/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 02/04/2020 19:20:37
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for dme_hbaseageing_manage
-- ----------------------------
DROP TABLE IF EXISTS `dme_hbaseageing_manage`;
CREATE TABLE `dme_hbaseageing_manage`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '老化名字',
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '连接地址',
  `port` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '端口号',
  `name_space` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '命名空间',
  `day` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '老化天数',
  `formatter` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '日期格式',
  `create_user` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_user` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of dme_hbaseageing_manage
-- ----------------------------
INSERT INTO `dme_hbaseageing_manage` VALUES ('1a2a5674ce7f4fad846a938392094dff', 'HBASE老化', '127.0.0.1', '21000', 'project', '11', 'yyyyMMdd', 'admin', '2019-09-30 14:48:31', NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
