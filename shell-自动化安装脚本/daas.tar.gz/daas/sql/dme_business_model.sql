/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 02/04/2020 15:50:54
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for dme_business_model
-- ----------------------------
DROP TABLE IF EXISTS `dme_business_model`;
CREATE TABLE `dme_business_model`  (
  `ID` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Pid` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0',
  `BusinessModules` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '业务名称',
  `Creator` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `sort` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of dme_business_model
-- ----------------------------
INSERT INTO `dme_business_model` VALUES ('133be6a356024c609fe444e770fc8ae9', '9e3a2b90cdf14386bc4ea3ab4733afc1', '数据分发', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('1d38adef4d974b84999e284ba15e77a3', 'e8a8da419d5b45ad861533fac8bc6034', '3.单位预算执行率分析', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('21e8adf4de89430187368e2f198d9264', 'e8a8da419d5b45ad861533fac8bc6034', ' 1.项目集中在年底支出', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('31b2b432489e4ff58ae2f7c7176b07e8', '9e3a2b90cdf14386bc4ea3ab4733afc1', '数据提取', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('42005fd32f7246d0949eafa1987e36f7', '0', '主题库抽取', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('5a4211fbae8d4f8cbf6a79b8c4aa46da', '42005fd32f7246d0949eafa1987e36f7', 'ztkcq01', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('5aab7d90fd544886b00f3c8824e8f2e7', 'bbb8bb1ae94b4d1d850d747e65bd4f90', 'zykcq01', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('7622f436f36b4c4a9fd8a0b917f06009', '9e3a2b90cdf14386bc4ea3ab4733afc1', '数据标签', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('8dab9ff04c804a76b80e14c9ac03897d', 'e8a8da419d5b45ad861533fac8bc6034', '2.预算单位财政支付总额前10名供应商', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('94855f2b291145778a1b18a0cecd7e70', '21e8adf4de89430187368e2f198d9264', '展示', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('94cb77d056964a2296bfd26650383c33', 'e8a8da419d5b45ad861533fac8bc6034', 'uuu', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('9e3a2b90cdf14386bc4ea3ab4733afc1', '0', '演示', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('a441e4d0080242c982fe4e301525587b', '9e3a2b90cdf14386bc4ea3ab4733afc1', '数据清洗', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('b55a0354d4ff46d19179e41d9890fb98', '9e3a2b90cdf14386bc4ea3ab4733afc1', '数据对账', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('bbb8bb1ae94b4d1d850d747e65bd4f90', '0', '资源库抽取', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('c378abb5df6e463283674513b5cbf6c2', '9e3a2b90cdf14386bc4ea3ab4733afc1', '数据分级', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('cd478bcbdaff4db8b9c4d57838ddef6d', '0', '原始库数据抽取', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('d0a377c3cb994843ad5dfb87905db18f', '9e3a2b90cdf14386bc4ea3ab4733afc1', '演示勿动_其他流程', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('d8870f81c5b54b5fbe09018feb12028c', 'cd478bcbdaff4db8b9c4d57838ddef6d', 'yskcq01', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('e8a8da419d5b45ad861533fac8bc6034', '0', '业务库抽取', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('ecbe955f7a12475f980920e217a73a38', '9e3a2b90cdf14386bc4ea3ab4733afc1', '数据关联', 'admin', NULL);
INSERT INTO `dme_business_model` VALUES ('f9877e5910084a33acc36b2d7e90e3b9', '9e3a2b90cdf14386bc4ea3ab4733afc1', '数据对比', 'admin', NULL);

SET FOREIGN_KEY_CHECKS = 1;
