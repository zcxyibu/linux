/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 03/04/2020 09:28:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for data_set_train
-- ----------------------------
DROP TABLE IF EXISTS `data_set_train`;
CREATE TABLE `data_set_train`  (
  `id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据集id',
  `name` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据集名称',
  `version` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据集版本',
  `type` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '数据集类型(0文本 1图片 2音频 3视频)',
  `store_path` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '存储路径',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_user` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '训练数据集' ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of data_set_train
-- ----------------------------
INSERT INTO `data_set_train` VALUES ('002', '反扒', 'V1.2', '002', '/data01', '反扒训练数据', '2019-08-13 10:58:28', '刘光荣', NULL);
INSERT INTO `data_set_train` VALUES ('003', '侦查', 'V1.2', '003', '/data02', '侦查训练数据', '2019-08-13 10:59:48', '刘光荣', NULL);
INSERT INTO `data_set_train` VALUES ('004', '自然语义', 'V1.2', '004', '/data03', '自然语义训练数据', '2019-08-13 10:59:48', '刘语义', '2019-09-20 11:18:15');
INSERT INTO `data_set_train` VALUES ('005', '评分', 'V1.2', '005', '/data04', '评分训练数据', '2019-08-13 10:59:48', '刘语义', '2019-09-20 11:18:15');

SET FOREIGN_KEY_CHECKS = 1;
