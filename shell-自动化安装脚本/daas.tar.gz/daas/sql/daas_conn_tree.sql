/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 03/04/2020 10:50:36
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for daas_conn_tree
-- ----------------------------
DROP TABLE IF EXISTS `daas_conn_tree`;
CREATE TABLE `daas_conn_tree`  (
  `id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '树的名称',
  `pid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `pids` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `creator` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `update_user` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `update_time` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of daas_conn_tree
-- ----------------------------
INSERT INTO `daas_conn_tree` VALUES ('13b693365af44c6792ef5bbb0fc941df', '连接管理分类', '0', '0', 'admin', '2019-04-01 20:52:07', NULL, NULL);
INSERT INTO `daas_conn_tree` VALUES ('2a0b5661d1ec40e4b5ac739293ccef85', '图数据库连接', '13b693365af44c6792ef5bbb0fc941df', '13b693365af44c6792ef5bbb0fc941df', 'admin', '2019-09-18 16:12:31', NULL, NULL);
INSERT INTO `daas_conn_tree` VALUES ('547a998d99cc44e5ac692e2c3deffc3a', '数据仓库连接', '13b693365af44c6792ef5bbb0fc941df', '13b693365af44c6792ef5bbb0fc941df', 'admin', '2019-08-28 10:31:22', NULL, NULL);
INSERT INTO `daas_conn_tree` VALUES ('7d5cd2efdferfa34qdc5r5dsswsfeecb', '本地HDFS连接', '13b693365af44c6792ef5bbb0fc941df', '13b693365af44c6792ef5bbb0fc941df', 'admin', '2019-04-02 16:46:49', NULL, NULL);
INSERT INTO `daas_conn_tree` VALUES ('8c7c9a7c49894c5abdf7c7171e3403fb', '远程文件连接', '13b693365af44c6792ef5bbb0fc941df', '13b693365af44c6792ef5bbb0fc941df', 'admin', '2019-08-03 14:34:53', 'admin', '2019-09-18 16:41:42');
INSERT INTO `daas_conn_tree` VALUES ('d18b7c30679e41e5bf30fa77d56a34de', '传统数据库连接', '13b693365af44c6792ef5bbb0fc941df', '13b693365af44c6792ef5bbb0fc941df', 'admin', '2019-08-03 14:35:03', 'admin', '2019-08-21 13:17:37');

SET FOREIGN_KEY_CHECKS = 1;
