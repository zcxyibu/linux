/*
 Navicat Premium Data Transfer

 Source Server         : 162.168.168.71
 Source Server Type    : MySQL
 Source Server Version : 50625
 Source Host           : 162.168.168.71:32874
 Source Schema         : daas

 Target Server Type    : MySQL
 Target Server Version : 50625
 File Encoding         : 65001

 Date: 02/04/2020 17:20:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
/*

-- ----------------------------
-- Table structure for daas_warning_page_info
-- ----------------------------
DROP TABLE IF EXISTS `daas_warning_page_info`;
CREATE TABLE `daas_warning_page_info`  (
  `task_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '预警任务id',
  `task_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '预警任务名称',
  `rule_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '预警任务id',
  `rule_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '预警规则名',
  `detail_content` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '紧急程度,严重、一般、轻微',
  `content` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '预警内容',
  `status` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '是否已读 0:未读  1:已读',
  `create_time` timestamp(0) NULL DEFAULT NULL COMMENT '预警时间'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
*/

-- ----------------------------
-- Records of daas_warning_page_info
-- ----------------------------
INSERT INTO `daas_warning_page_info` VALUES ('12345324231', '数据接入状态监控任务', '31fbf6a7128544aea36d37a300c17e03', '状态检测', '162.168.168.71', '故障于2019-08-12 11:21:32,在数据接入状态监控任务', '1', '2019-08-14 14:50:12');
INSERT INTO `daas_warning_page_info` VALUES ('12345324233', '数据质量检测监控任务', 'efaf7f500be0471285bcd85038b356ba', '数据质量检测', '162.168.168.71', '故障于2019-09-08 16:23:55,在数据质量检测监控任务', '1', '2019-08-14 14:50:12');
INSERT INTO `daas_warning_page_info` VALUES ('12345324234', '数据质量检测监控任务', 'efaf7f500be0471285bcd85038b356ba', '数据质量检测', '162.168.168.71', '故障于2019-06-12 08:01:30,在数据质量检测监控任务', '0', '2019-08-14 14:50:12');
INSERT INTO `daas_warning_page_info` VALUES ('12345324232', '敏感词状态监控任务', '044aaa6bfa1541f0b313d7fafc619663', '告警敏感词检测', '162.168.168.71', '故障于2019-07-12 12:29:12,在敏感词状态监控任务', '0', '2019-08-14 14:50:12');

SET FOREIGN_KEY_CHECKS = 1;
