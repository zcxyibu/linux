#!/bin/bash

#固定参数
mysql_host="127.0.0.1"
mysql_port="3306"
mysql_user="rhino"
mysql_passwd="rhino"
mysql_path="/home/rhino/mysql-5.6.25-linux-x86_64/bin/mysql"

pwd_path=$(cd `dirname $0`; pwd)
neo4j_path="/home/rhino/neo4j-community-3.4.7/bin"
#函数:错误执行脚本打印help帮助信息
help()
{
cat<<HELP
#-----------------------------------------------------------------------------------#
###使用说明###

./osint_person.sh -a id编码  -b e_id编码 

如果json中莫迪的e_id固定，则e_id使用：PERe04321bc-c2b9-490e-9048-fb8d49d207cb

样例

./osint_person.sh -a 10012  -b PERe04321bc-c2b9-490e-9048-fb8d49d207cb
#-----------------------------------------------------------------------------------#
HELP
}

#函数:判断上条命令是否执行成功
if_else()
{
    if [ $1 = 0 ];then
        echo "succeed"
    else
        echo "failed"
        exit 1
    fi
}

#循环读取参数并赋值
while getopts ":a:b:" opt
do
    case $opt in
        a)
        id=$OPTARG
        echo "id:$OPTARG"
        ;;
        b)
        e_id=$OPTARG
        echo "e_id:$OPTARG"
        ;;
        ?)
        echo "input error"
        exit 1;;
    esac
done

if [ "$id" = "" ] || [ "$e_id" = "" ];then
    help
    exit 1
else
    echo "------------输入参数成功--------------"
fi

values="{\"entity_desc\":\"{\\\"姓名\\\":\\\"Shri Narendra Modi\\\",\\\"配偶\\\":\\\"Jashodaben ( m. 1968) (estranged)\\\",\\\"居住地\\\":\\\"7, Lok Kalyan Marg , New Delhi\\\",\\\"政党\\\":\\\"Bharatiya Janata Party\\\",\\\"e_id\\\":\\\"$e_id\\\",\\\"出生地\\\":\\\"Narendra Damodardas Modi  ( 1950-09-17 ) 17 September (age 68) 1950  Vadnagar , Bombay State , India (present-day Gujarat ) \\\"}\",\"e_id\":\"$e_id\",\"id\":$id,\"e_type\":\"基础标签\",\"label_value\":\"印度,总理,吠舍,政治家,茶农之子,印度教主义者,民族主义,藏独,反穆斯林,首尔和平奖得主,非典型印度政客\",\"label_level\":\"{\\\"吠舍\\\":\\\"normal\\\",\\\"政治家\\\":\\\"normal\\\",\\\"总理\\\":\\\"normal\\\",\\\"印度教主义者\\\":\\\"normal\\\",\\\"非典型印度政客\\\":\\\"normal\\\"}\"}"
#values="{\"entity_desc\":\"{\\\"姓名\\\":\\\"Shri Narendra Modi\\\",\\\"配偶\\\":\\\"Jashodaben ( m. 1968) (estranged)\\\",\\\"居住地\\\":\\\"7, Lok Kalyan Marg , New Delhi\\\",\\\"政党\\\":\\\"Bharatiya Janata Party\\\",\\\"e_id\\\":\\\"$e_id\\\",\\\"出生地\\\":\\\"Narendra Damodardas Modi  ( 1950-09-17 ) 17 September (age 68) 1950  Vadnagar , Bombay State , India (present-day Gujarat ) \\\"}\",\"e_id\":\"$e_id\",\"id\":$id,\"e_type\":\"基础标签\",\"label_value\":\"印度,总理,吠舍,政治家,茶农之子,印度教主义者,民族主义,藏独,反穆斯林,首尔和平奖得主,非典型印度政客\",\"label_level\":\"{\\\"吠舍\\\":\\\"normal\\\",\\\"政治家\\\":\\\"normal\\\"}\"}"
#插数据模板
#curl -XPOST 'http://0.0.0.0:9200/entity_label/entity_label?pretty' -H 'Content-Type:application/json' -d  '{"id":10006,"e_id":"PERe04321bc-c2b9-490e-9048-fb8d49d207cc","e_type":"基础标签","label_value":"印度,总理,吠舍,政治家,茶农之子,印度教主义者,民族主义,藏独,反穆斯林,首尔和平奖得主,非典型印度政客","entityy_desc":"{\"姓名\":\"Shri Narendra Modi\", \"配偶\": \"Jashodaben ( m. 1968) (estranged)\", \"居住地\": \"7, Lok Kalyan Marg , New Delhi\", \"政党\": \"Bharatiya Janata Party\", \"e_id\": \"PERe04321bc-c2b9-490e-9048-fb8d49d207cb\", \"出生地\": \"Narendra Damodardas Modi  ( 1950-09-17 ) 17 September (age 68) 1950  Vadnagar , Bombay State , India (present-day Gujarat ) \"}"}'

echo "------------插入数据到es--------------"
#取消索引只读模式
curl -XPUT 'http://0.0.0.0:9200/_all/_settings?' -H 'Content-Type:application/json' -d  '{"index.blocks.read_only_allow_delete":null}'
echo -e "\n"
echo  curl -XPOST "http://0.0.0.0:9200/entity_label/entity_label?pretty" -H "Content-Type:application/json" -d "$values"
echo "------------插入结果--------------"
#curl -XPOST "http://0.0.0.0:9200/entity_label/entity_label?pretty" -H "Content-Type:application/json" -d "$values"
if_else $?


#个人详情-线上动态
echo "----------个人详情-------------"
insert="INSERT INTO   osint_demo.TabareVazquez  VALUES ('$id', 'Shri Narendra Modi', '2020-03-23 14:00:00', '@TabareVazquez  URUGUAY  PlanVueltaALaPatria @ONU_es @Pontifex_es @mbachelet @unasurhttps://twitter.com/EmbaVEArgentina/status/1117881775512932352 …', 'commnets([])'),('$id', 'Shri Narendra Modi', '2020-03-26 15:10:00', '@opsoms @UNICEFenEspanol @ONU_derechos @UNIONEUROPEA @FedericaMog @ParlamentoEurop @Union_Africaine @CARICOMorg @ONU_es @ONUVEGinebra @antonioguterres @TabareVazquez @lopezobrador_ @APEC_CEOsummit @ASEAN @OPECSecretariat @CITGO @PDVSABolivia @CubaMINREX @SRE_mx @CPIJ_PCJIhttps://twitter.com/embavenezcorea/status/1117544339805106176 …', 'commnets([])'),('$id', 'Shri Narendra Modi', '2020-03-30 17:05:00', 'Y a que Embajada se va a meter ahora?  @TabareVazquez cierra tu residencia!', 'commnets([])');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO osint_demo.twitter_demo   VALUES ('$id', '$e_id', '2020-03-23 14:00:00', 'My best wishes to these adorable young Chowkidars!  Happy to see their Josh.'),('$id', '$e_id', '2020-03-26 15:10:00', 'Great!  Best wishes to the youngsters.'),('$id', '$e_id', '2012-03-30 17:05:00', 'Good effort!  Keep doing so till the elections.');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#个人详情-label获取
insert="INSERT INTO  osint_demo.news_label  VALUES ('$e_id', 'China shields Masood Azhar: Rahul Gandhi calls PM weak, says Modi scared of Xi', 'Congress president Rahul Gandhi has hit out at Prime Minister Narendra Modi over China blocking the initiative to tag Jaish-e Mohammad chief Masood Azhar as a global terrorist by the United Nations Security Council.Hours after India expressed its disappointment over China blocking the move for the fourth time, Rahul Gandhi took to Twitter, and said, \'Weak Modi is scared of Xi. Not a word comes out of his mouth when China acts against India.\'As he quoted a news report on Masood Azhar, Rahul Gandhi slammed Prime Minister Modi over China diplomacy.\'NaMo\'s China Diplomacy: Swing with Xi in Gujarat, Hug Xi in Delhi, Bow to Xi in China,\' Rahul Gandhi wrote on Twitter.The Congress had on Wednesday attacked the BJP government after China blocked the bid at the UN to designate Pakistan-based terror group JeM chief Masood Azhar as a \'global terrorist\', saying Prime Minister Narendra Modi\'s foreign policy has been a series of \'diplomatic disasters\'. The opposition party also slammed China for blocking the move.Congress\' chief spokesperson Randeep Surjewala had said it was a sad day in the global fight against terrorism. \'China blocking Masood Azhar\'s designation as a global terrorist reaffirms Chinese position of being an inseparable ally of terrorism\'s breeding ground -- Pakistan,\' he had tweeted.\'Sadly, Modiji\'s foreign policy has been a series of diplomatic disasters,\' the Congress spokesperson had said.', 'pakistan india terror attack china', 'NaMo\'s China Diplomacy: Swing with Xi in Gujarat, Hug Xi in Delhi, Bow to Xi in China,\' Rahul Gandhi wrote on Twitter.The Congress had on Wednesday attacked the BJP government after China blocked the bid at the UN to designate Pakistan-based terror group JeM chief Masood Azhar as a \'global terrorist\', saying Prime Minister Narendra Modi\'s foreign policy has been a series of \'diplomatic disasters\'.', 'https://www.indiatoday.in/india/story/masood-azhar-rahul-gandhi-modi-pm-block-terrorist-1477657-2020-03-14', 1, 0, '2020-03-14 00:00:00');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#个人详情-事件动态及表格
insert="INSERT INTO osint_demo.news_label VALUES ('$e_id', 'India-US agree to strengthen bilateral defence cooperation on Sitharaman?? visit', 'Defence Minister Nirmala Sitharaman is on an official visit to the United States of America from December 2 to 7, on the invitation of US Secretary of Defence James N Mattis.Sitharaman met Mattis in Washington DC. A dinner was also hosted in her honour. Prior to the meeting, she was received by Secretary Mattis on her arrival at the Pentagon and accorded the Armed Forces Enhanced Honours Cordon welcome.During their meeting, discussions were held on the growing partnership between India and US in the defence sphere. Views were also exchanged on a broad range of bilateral and international issues of mutual interest.The ministers reviewed the ongoing initiatives to further strengthen bilateral defence cooperation, as a key pillar of the strategic partnership between India and the USA.The two countries also agreed to further strengthen bilateral defence cooperation, building on the discussions and outcomes of the \'2 + 2 Dialogue\' held in September 2018.Sitharaman highlighted the steps taken by government of India to promote defence sector manufacturing, under Prime Minister Narendra Modi\'s flagship Make in India programme.Yesterday Sitharaman visited the US Department of State, where she signed the condolence book for former US President George HW Bush. She also paid respects at the Tomb of the Unknown Soldier and laid a wreath at the Arlington National Cemetery Memorial.Following her engagements in Washington DC, Nirmala Sitharaman will be visiting Reno, where she will hold interactions with select leaders of Indian community in the US.Later, she will visit San Francisco where she would address a roundtable meeting at Stanford. She will also visit the Defence Innovation Unit (DIU) of the US Department of Defence and interact with start-ups and venture capitalists associated with this unit.From December 5-7 Sitharaman will visit Honolulu, which is the headquarters of the US Pacific Command, recently renamed as Indo-Pacom. During the visit, she will hold meetings with the commander of Indo-Pacom, Admiral Philip S Davidson. She will also visit the Joint Base Pearl Harbour Hickam, where she would board a US guided missile destroyer and be briefed on activities of the Indo-Pacom. ', 'govern defenc articl sitharaman minist', 'Prior to the meeting, she was received by Secretary Mattis on her arrival at the Pentagon and accorded the Armed Forces Enhanced Honours Cordon welcome.During their meeting, discussions were held on the growing partnership between India and US in the defence sphere.', 'https://www.indiatoday.in/india/story/india-us-agree-to-strengthen-bilateral-defence-cooperation-on-sitharaman-s-visit-1402205-2019-12-04', 0, 1, '2019-12-04 00:00:00');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO  osint_demo.news_label  VALUES ('$e_id', 'China shields Masood Azhar: Rahul Gandhi calls PM weak, says Modi scared of Xi', 'Congress president Rahul Gandhi has hit out at Prime Minister Narendra Modi over China blocking the initiative to tag Jaish-e Mohammad chief Masood Azhar as a global terrorist by the United Nations Security Council.Hours after India expressed its disappointment over China blocking the move for the fourth time, Rahul Gandhi took to Twitter, and said, \'Weak Modi is scared of Xi. Not a word comes out of his mouth when China acts against India.\'As he quoted a news report on Masood Azhar, Rahul Gandhi slammed Prime Minister Modi over China diplomacy.\'NaMo\'s China Diplomacy: Swing with Xi in Gujarat, Hug Xi in Delhi, Bow to Xi in China,\' Rahul Gandhi wrote on Twitter.The Congress had on Wednesday attacked the BJP government after China blocked the bid at the UN to designate Pakistan-based terror group JeM chief Masood Azhar as a \'global terrorist\', saying Prime Minister Narendra Modi\'s foreign policy has been a series of \'diplomatic disasters\'. The opposition party also slammed China for blocking the move.Congress\' chief spokesperson Randeep Surjewala had said it was a sad day in the global fight against terrorism. \'China blocking Masood Azhar\'s designation as a global terrorist reaffirms Chinese position of being an inseparable ally of terrorism\'s breeding ground -- Pakistan,\' he had tweeted.\'Sadly, Modiji\'s foreign policy has been a series of diplomatic disasters,\' the Congress spokesperson had said.', 'pakistan india terror attack china', 'NaMo\'s China Diplomacy: Swing with Xi in Gujarat, Hug Xi in Delhi, Bow to Xi in China,\' Rahul Gandhi wrote on Twitter.The Congress had on Wednesday attacked the BJP government after China blocked the bid at the UN to designate Pakistan-based terror group JeM chief Masood Azhar as a \'global terrorist\', saying Prime Minister Narendra Modi\'s foreign policy has been a series of \'diplomatic disasters\'.', 'https://www.indiatoday.in/india/story/masood-azhar-rahul-gandhi-modi-pm-block-terrorist-1477657-2020-03-14', 0, 0, '2020-03-14 00:00:00');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO  osint_demo.news_label  VALUES ('$e_id', 'RSS leader calls for boycott of Chinese goods', 'Gangtok, Apr 8 (PTI) Slamming China for its expansionist agenda, senior RSS leader Indresh Kumar today called for boycott of Chinese goods to undermine the country economically.\'China can not be defeated militarily and so it is imperative to hit its economy by boycotting Chinese goods altogether,\' he said at a book release function here.Beijing gets easily rattled by boycott of its goods by other countries, Kumar, the founder of the Indo-Tibetan Friendship Society, observed.Taking potshots at the expansionist agendas of China, Kumar said that it has been working for years to corner India from all sides for which it has generously funded development projects in neighbouring countries like Bangladesh, Myanmar, Nepal, Sri Lanka and Pakistan.Flaying the successive Indian governments for falling to Chinese overtures for friendly relations over the years, the RSS leader said: \'Let none of us believe what China says or does on maintaining good relations with neighbours, including India, as it is a non-believer nation which has nursed imperialist designs since ages.\'\'We also must understand that Chinas symbol is dragon which spits fire and swallows prey animals,\' Kumar said and warned that it will be disastrous to take Beijings expansionist plans lightly.\'The world has seen how China gobbled up Tibet in 1950s on the same lines it had usurped territories of a number or East Asian countries since its emergence as a military power in the second half of the 20th century,\' he said.The RSS functionary complimented the Narendra Modi government for its deft handling of Doklam standoff last year and said that a strong measure by India forced China to have a re-think about its expansionist plan.China had deployed about four lakh soldiers with an aim to capture Doklam in Bhutan, but India foiled its designs by rushing 34,000 troops along with military support that forced Beijing to back off after months-long standoff.It was a perfect response from India and that is how one can contain the Chinese imperialist game plan, he said lavishing praise on the Modi government. PTI KDK JM', 'pakistan india terror attack china', 'Gangtok, Apr 8 (PTI) Slamming China for its expansionist agenda, senior RSS leader Indresh Kumar today called for boycott of Chinese goods to undermine the country economically.', 'https://www.indiatoday.in/pti-feed/story/rss-leader-calls-for-boycott-of-chinese-goods-1207594-2018-04-08', 0, 1, '2018-04-08 00:00:00');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#个人详情-score图展示
insert="INSERT INTO osint_demo.news_graph  VALUES ('$e_id', 0, '2020-03-27 14:33:37', 84, '2019-12-31'),('$e_id', 0, '2019-12-31 14:00:00', 66, '2019-06-30'),('$e_id', 0, '2019-06-30 15:00:00', 74, '2019-01-15');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

echo "----------历史线-------------"
#历史线
insert="INSERT INTO  osint_demo.dalai_trace_demo  VALUES ('2020-02-26', '2020-02-26至2020-02-26', 'Churu (Rajasthan)', 'PM Modi to hold rally in Rajasthan\'s Churu on February 26', '28.2978742', '74.931778', 'Prime Minister Narendra Modi will address a public meeting in Churu district of Rajasthan on Tuesday, a BJP spokesperson said. Preparations for the rally to be held on February 26 are being done at party and administration level, he said.It will be Prime Minister Modi\'s second public meeting in Rajasthan within four days. He had visited Tonk on February 23.State Chief Secretary D B Gupta held a high-level meeting to review the preparations for the Tuesday\'s rally', 'https://www.moneycontrol.com/news/india/pm-modi-to-hold-rally-in-rajasthans-churu-on-february-26-3581901.html', 'moneycontrol', '80', '国内活动');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO osint_demo.dalai_trace_demo  VALUES ('2020-02-19', '2020-02-19至2020-02-19', 'Varanasi (Uttar Pradesh)', 'Negative minded people are insulting our engineers, says PM Modi', '25.3209013', '82.9210679', 'Prime Minister Narendra Modi on Tuesday reached Varanasi, where he is scheduled to announce projects worth Rs 2,900 crore. PM Modi will be inaugurating 31 projects which have already been completed. \"PM Modi will flag off the first ever diesel to electric converted locomotive at diesel locomotive works in Varanasi. He will also inspect the locomotive and visit the exhibition,\" according to a statement released by the Prime Minister\'s Office.PM Modi has inaugurated a twin electric WAGC3 loco of 10,000 HP developed by Diesel Locomotive Works, manufactured under Modi government\'s ambitious \'Make in India\' initiative. The converted locos are expected to result in less greenhouse gas emissions and better efficient locomotives for the Indian Railways.', 'https://www.newsnation.in/election/lok-sabha-election-2019/live-pm-modi-reaches-varanasi-to-announce-projects-worth-rs-2900-crore-article-214562.html', 'newsnation', '85', '印度制造,机车,国内活动');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO osint_demo.dalai_trace_demo VALUES ('2020-02-15', '2020-02-15至2020-02-15', 'Uttar Pradesh', 'PM to visit Jhansi in Uttar Pradesh on 15 February 2019', '27.0793918', '76.3862468', 'The Prime Minister, Shri Narendra Modi, will visit Jhansi on 15 February 2019.To make India self-reliant in defence production Government of India had taken the decision to establish two defence corridors in the country, one at Tamil Nadu and the other in Uttar Pradesh. Jhansi is one of the six nodal points of the UP defence corridor. The Prime Minister during the UP Investors Meet held on February 2018, had announced the setting up of one such corridor in the Bundelkhand Region of UP.PM will inaugurate the electrification of 297 km long section of Jhansi- Khairar section. Electrification will lead to faster trains, reduced carbon emissions and sustainable environment.He will also dedicate to Nation the West- North Inter-Region Power Transmission Strengthening Project to ensure uninterrupted power supply to Western Uttar Pradesh.PM will inaugurate Pahari Dam Modernization Project. Pahari Dam is a water storage dam situated on Dhasan river in Jhansi district.Keeping in line with the Government’s vision of providing drinking water to all, PM will lay the Foundation Stone of Piped Water Scheme for the rural areas of Bundelkhand Region. The project is significant as it will ensure water supply to the drought prone Bundelkhand region. Foundation Stone of Jhansi City Drinking Water Scheme Phase-II under AMRUT will also be laid by the PM.PM will lay the Foundation Stone of Coach Refurbishing Workshop in Jhansi. The facility will create employment opportunities to the Bundelkhand region.PM will lay the foundation stone of doubling of 425 km long Jhansi-Manikpur and Bhimsen-Khairar railway lines. It will not only provide easy movement of trains but also help in the overall development of Bundelkhand region.The Prime Minister, Shri Narendra Modi, earlier visited Vrindavan and Varanasi in Uttar Pradesh to serve the three billionth meal to underprivileged children from schools and for the Pravasi Bharatiya Diwas respectively.', 'https://www.narendramodi.in/pm-to-visit-jhansi-in-uttar-pradesh-tomorrow--543535', 'narendramodi app', '95', '经济建设,交通,水利,就业');INSERT INTO osint_demo.dalai_trace_demo VALUES ('2020-02-15', '2020-02-15至2020-02-15', 'Uttar Pradesh', 'PM to visit Jhansi in Uttar Pradesh on 15 February 2019', '27.0793918', '76.3862468', 'The Prime Minister, Shri Narendra Modi, will visit Jhansi on 15 February 2019. The Prime Minister will inaugurate or lay foundation stone of various development projects in Jhansi.PM will lay the Foundation Stone of Defence Corridor in Jhansi, Uttar Pradesh', 'https://www.narendramodi.in/pm-to-visit-jhansi-in-uttar-pradesh-tomorrow--543535', 'narendramodi app', '95', '经济建设,交通,水利,就业');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

insert="INSERT INTO  osint_demo.dalai_trace_demo  VALUES ('2020-02-17', '2020-02-17至2020-02-17', 'Jharkhand', 'During his Jharkhand visit, PM Narendra Modi to inaugurate several development projects', '23.6397571', '83.3908583', 'prime Minister Narendra Modi will lay the foundation stone for hospitals in Hazaribagh, Dumka and Palamau in Jharkhand on Sunday and inaugurate a host of development schemes during his visit to the state, an official statement said.The prime minister will lay the foundation stone online for four 500-bedded hospitals in Hazaribagh, Dumka, Palamau and Jamshedpur.This apart, he will lay foundation stone for Hazaribagh urban line water supply scheme and rural drinking water supply -- four schemes for Hazaribagh and two for Ramgarh.Modi, who is scheduled to reach Hazaribagh at 2.30 pm, will also inaugurate the newly constructed building at the Women\'s Engineering College in Ramgarh district.He will inaugurate one rural water supply scheme for Ramgarh and three for Hazaribagh besides a sewage treatment plant and \'Madhusudan Ghat\' under Namami Gange - National Mission for Clean Ganga programme.The prime minister will lay foundation stone for 2,718 piped water supply schemes for primitive tribal community and a tribal studies centre at the Hazaribagh-based Acharya Vinoba Bhave University.The day will also mark the beginning of deposit of money in farmers\' account for purchase of mobile phones under e-NAM (National Agriculture Market) scheme, distribution of milk among government school children under PM Gift Milk Scheme and house warming of beneficiaries under the Pradhan Mantri Awas Yozana, the release said.', 'https://www.indiatoday.in/india/story/during-his-jharkhand-visit-pm-narendra-modi-to-inaugurate-several-development-projects-1458032-2019-02-17', 'indiatoday', '90', '医疗,经济建设');"
echo $mysql_path -h0 -P$mysql_port -u$mysql_user -p$mysql_passwd -e "$insert"
#"$mysql_path" -h0 -P"$mysql_port" -u"$mysql_user" -p"$mysql_passwd" -e "$insert"
if_else $?

#-----关系图-----
echo "------------关系图--------------"
#停止neo4j
$neo4j_path/neo4j  stop
#备份库
$neo4j_path/neo4j-admin dump --database=graph.db --to=$pwd_path/
mv $pwd_path/graph.db.dump   $pwd_path/graph_csv/graph_bak.db.dump
#删除库
rm -rf $neo4j_path/../data/databases/graph.db
#导入库
$neo4j_path/neo4j-admin load --from="$pwd_path/graph_csv/graph.db.dump"
#启动neo4j
$neo4j_path/neo4j  start

echo "----------end-------------"
